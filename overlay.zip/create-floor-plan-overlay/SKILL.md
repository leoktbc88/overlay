---
name: create-floor-plan-overlay
description: Create C, a precise Hong Kong estate stock or price-table overlay, from A, an original floor plan or estate map, and B, a stock list, price list, CSV, Excel sheet, PDF, or scanned table. Use for requests to show available flats on a map, annotate selected tower/flat stacks, reproduce the Garden Regency 芊御 layout, or export clear SVG price tables with arrows. Preserve the original artwork and render new tables and text as SVG vectors without an image-generation model.
---

# Floor Plan Stock Overlay

Produce an accurate, readable A + B → C overlay. Use the original plan as an embedded background; create the tables, text, flat markers, and connectors programmatically. Default to Traditional Chinese labels, original listed HKD prices, and exactly one standalone editable SVG showing the complete estate map with all towers. Keep inspection previews internal; deliver additional formats or separate maps only when requested.

## Resources

- Read [data-and-template.md](references/data-and-template.md) before preparing renderer input or mapping a new estate.
- Read [garden-regency.md](references/garden-regency.md) when using the supplied 芊御 full-estate template or comparing historical examples.
- Read [reference-matching.md](references/reference-matching.md) first when the user supplies a desired output C or says the result should match a reference. Follow its table style and map versions, subject to the user's requested output scope and format.
- Use `scripts/build_overlay.py` for deterministic composition, filtering, pagination, font embedding, and optional PNG rendering.
- Use `scripts/verify_overlay.py` to verify displayed rows and the embedded map against the normalized inputs.
- Reuse `assets/garden-regency-full-estate.json` with its paired original JPEG only for that verified source. It maps all three towers and protects their actual floor drawings. Treat the asset as a plan template, never as a stock feed.

## 1. Resolve A and B

Use supplied files and existing authorized context before asking questions. Resolve an actual original map and an actual source list; never reconstruct prices or floor rows from a visual example. Apply PDF or spreadsheet skills when applicable. Inspect plan labels and source table pages visually.

When C is supplied as the required style, inspect every reference page and compare it against B. Preserve its compact price labels/order, grouping, table positions, colours and callouts. For a requested single full-map SVG, select its full-estate overview; additional source pages are evidence rather than automatic deliverables. Include map variants and payment-plan annexes only when requested. Keep standard/terrace/reference scopes distinct. Use C's values only after reconciling them with authoritative B; preserve documented B corrections visibly.

Honor explicit tower/flat filters. For “all Batch 1,” use every qualifying record in that specific batch, including flats outside an earlier single-flat demonstration. Distinguish the plan date, source date, and generation date.

## 2. Extract and verify B

Prefer native PDF text with word coordinates or spreadsheet cell values. For scanned pages, use traditional OCR and inspect uncertain cells. Preserve source page/row references for every record.

Normalize estate, phase, tower, floor, and flat identifiers without collapsing meaningful labels: A differs from A1; 2 differs from 2A; G/F differs from 1/F. Preserve omitted floors. Distinguish saleable square feet from square metres and terrace area. Display every supplied named payment plan, such as A1, B1, C1, and all quoted/reference/tender prices in separate labeled columns. Select a single basis only when explicitly requested. Preserve missing values as null, displayed as a dash; do not copy a quoted price into a missing plan price.

Use an independent second extraction or direct source-page comparison to verify every included floor, price, and rate. Check unit totals, unique identities, group totals, and source-page coverage. Reject conflicting duplicates and unresolved mappings; do not silently choose one record. Keep unit identity as estate + phase + tower + floor + flat within one snapshot.

Treat a price-list entry as **listed**, not proof of current availability. Preserve explicit inventory statuses when B supplies them. Do not interpret a missing unit as sold. Show the source's price and rate values; calculate a missing rate only when authorized, mark it as calculated, and retain the calculation basis. Do not apply discounts or rebates by default.

Keep floor-unspecified examples in `references`, separate from counted units. Preserve conflicting listed/calculated rates in separate labeled columns and record the source note rather than silently correcting them. Write verified records to the schema 2 JSON contract in the reference for multiple prices. Do not use historical bundled examples as newly uploaded stock.

## 3. Verify the plan mapping

Match tower + flat to a visually checked anchor on the main plan, avoiding the inset and repeated labels. Save original image dimensions, SHA-256, applicable floors, source-coordinate anchors, and protected polygons enclosing every actual tower floor drawing. Reuse anchors and polygons only when the source checksum matches. For a changed plan, review and remap it.

Use a separate template to depict terrace floors, penthouses, or different layouts accurately. To show their stock against the full estate map, permit a verified stack-location mapping only with `map_role: "stack_location"`, explicit anchor-level `stack_location_floors`, and a visible `floor_note` explaining that their exact floor layout differs. Never imply that the standard-floor drawing depicts a terrace layout. Keep per-row areas visible when they differ. For a new estate, create and visually verify a JSON plan matching the reference. Keep unresolved rows visible in a review list before representing them as matched.

If separate terrace-floor maps are requested, use the reference's actual terrace drawings on their own pages. For a single full-map request, preserve the requested overview scope. If all stock is explicitly required on that map, include special-floor rows in distinct stack-location groups with visible layout/area notes; never imply the standard drawing depicts their exact geometry or silently omit them.

## 4. Generate C

Run the renderer from this skill directory using absolute input/output paths:

```bash
python3 scripts/build_overlay.py \
  --plan assets/garden-regency-full-estate.json \
  --stock /absolute/path/verified-stock.json \
  --output /absolute/path/estate-stock.svg
```

Add `--flat C` for only Flat C, repeat `--flat` for several flats, or use `--tower 2` to explicitly select Tower 2 from a multi-tower source. Without an explicit filter, the renderer includes every stock row and rejects any unmapped tower/flat rather than quietly losing it. Read the returned counts and filenames.

Retain exactly one complete estate floor map with all towers. Do not add a cropped map, overview thumbnail, or enlarged Tower 2 panel. Allow opaque tables to cover gardens, pools, roads, paths, and other map backgrounds. Never cover any protected tower floor drawing. Preserve important labels, the inset, compass, and legend using additional protected regions where space permits. Use `layout_mode: "background"` to place tables automatically in safe map areas and route leaders around other cards and towers. Group by tower/flat; show changed areas in explicit row columns or split variants when area is only in the header. Use real records without filling floor gaps. Display dates, price meanings, status semantics, and retain per-row source references in tooltips and metadata.

Preserve live `<text>` elements. Embed the original image and subset Traditional Chinese/Latin fonts. Use a common `viewBox` and transforms for the map, markers, and leaders. Keep white text readable on dark headers; avoid CSS rules overriding per-element fill. Use tabular price figures, measured column widths, and adequate row height; the background renderer defaults to 16-unit numeric text with 24-unit rows. The user accepts small text and will zoom manually. Increase the canvas/full-map scale and compact table placement to keep a single SVG; paginate only when requested. Never solve a collision by covering a tower. Keep source artwork colors intact.

Supply verified anchors and applicable floors or explicit location-only scope for every requested tower/flat. Reconcile counts across pages and any separate floor templates. Exclude references from unit totals. Do not omit unmatched towers or price plans silently.

## 5. Verify and deliver

Run the output verifier for every page:

```bash
python3 scripts/verify_overlay.py \
  --stock /absolute/path/verified-stock.json \
  --plan assets/garden-regency-full-estate.json \
  /absolute/path/estate-stock.svg
```

For paginated output, pass every page to one verifier invocation. Supply the same `--tower`/`--flat` selection used in rendering. Confirm that every source unit and reference appears exactly once, that all named columns and displayed values match, and that no extra records appear. Compare the decoded embedded background to the source checksum and bytes. In background mode, independently verify zero table intersections with protected tower polygons and zero table-to-table overlaps.

Render and visually inspect the full preview and a price-table crop at native resolution. Check Chinese glyphs, small text, clipping, wrong-tower arrows, covered labels, connector crossings, and source-date wording. Match PNG positions to the SVG. The background remains limited by A's resolution; only the new overlay is vector.

If PNG export lacks a renderer, retain the standalone SVG, use an available browser/graphics renderer with its exact fonts, and inspect that result. Report a missing requested export plainly; never substitute a UI screenshot.

Save requested final artifacts through the environment's normal artifact workflow. Return only the single full-map SVG link by default. State its included unit/tower scope briefly when needed; do not attach preview PNGs, PDFs, annexes or separate tower maps unless requested. Do not add extra approval steps for routine reusable templates or reversible composition.
