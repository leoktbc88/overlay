# Match a supplied example C

Treat an uploaded desired-output PDF/image as a layout specification when the user asks to match it. Inspect all its pages before choosing a renderer. Compare page scope, map version/orientation, table grouping/positions, columns/order, exact price labels, tower colours, arrow endpoints, room/area labels, date/footer wording, and payment-plan annexes. Verify the current B independently; never copy historical prices because C looks right.

Resolve the requested output scope before rendering. Default to one full-estate SVG. For Garden Regency, the accepted single-map output is reference page 1: all three towers and 216 standard-floor units. Keep the remaining pages as source evidence unless the user requests them. An explicit request for all 240 units requires distinct, annotated special-floor stack-location groups on the full map; do not silently equate the 216-row overview with all stock.

Garden Regency's six-page reference contains:

| Reference page | Contents | Scope |
|---|---|---|
| 1 | Full Towers 1–3 standard-floor map; 33 compact price tables | 216 units; floor, A1 Plan, B1 Plan, 光猪價 and listed PSF |
| 2–3 | Payment plans, rebates and explanatory terms | Source annexes; retain their stated dates/terms |
| 4 | Tower 2 actual 2/F terrace drawing | 12 reference/tender-price units; terrace areas and tender notes |
| 5 | Tower 2 standard-floor drawing and K/L mid-floor examples | 2 references; unspecified floors/quantities; exclude from unit counts |
| 6 | Tower 3 actual 2/F terrace drawing | 12 reference-price units; terrace areas |

Use all three towers on page 1, with one full map and no duplicate Tower 2 enlargement. Keep the white canvas, blue Tower 3/orange Tower 2/cyan Tower 1 header bars, pink flat/room headers, source room colours, area in the header, compact price columns, pale price-cell colours, and black callout arrows. Do not replace this with a nine-column audit table or merge 2/F rows into standard-floor tables. Keep calculated rates and source-evidence details in metadata/a verification record unless specifically requested visibly.

For the accepted single full-map SVG from this exact supplied snapshot, use:

```bash
python3 scripts/render_reference_overlay.py \
  --reference /absolute/path/desired-output.pdf \
  --stock /absolute/path/verified-stock.json \
  --pages 1 --output /absolute/path/main-estate.svg

python3 scripts/verify_reference_overlay.py \
  --reference /absolute/path/desired-output.pdf \
  --stock /absolute/path/verified-stock.json \
  --pages 1 -- /absolute/path/main-estate.svg
```

The renderer validates the complete source snapshot, then emits only the selected page. The selected-page verifier checks the 216 included rows, their 864 populated price/rate values and reference geometry. Render a preview internally for inspection; return only `main-estate.svg`.

Only when the complete six-page reproduction is requested, use:

```bash
python3 scripts/render_reference_overlay.py \
  --reference /absolute/path/desired-output.pdf \
  --stock /absolute/path/verified-stock.json \
  --output /absolute/path/main-estate.svg --png \
  --pdf /absolute/path/complete-layout.pdf

python3 scripts/verify_reference_overlay.py \
  --reference /absolute/path/desired-output.pdf \
  --stock /absolute/path/verified-stock.json \
  /absolute/path/main-estate.svg /absolute/path/main-estate-p02.svg \
  /absolute/path/main-estate-p03.svg /absolute/path/main-estate-p04.svg \
  /absolute/path/main-estate-p05.svg /absolute/path/main-estate-p06.svg
```

Apply the PDF skill's authoring marker before requesting the new PDF. The reference renderer preserves the original PDF's drawing geometry and all native text positions, embeds subset copies of its original fonts, reconstructs missing Unicode maps from PDF glyph evidence, and retains vector tables/text. Pages 2–3 are supplied raster annexes and remain at their original resolution. The estate/terrace maps are also raster source artwork; their overlay tables and leaders remain vector. The PNG preview defaults to width 3600; SVG reading relies on manual zoom.

The renderer requires the COMPLETE price snapshot and unit identities to match B. It rejects a changed amount, omitted/new unit, different terrace area or bedroom type, and unmapped source structure. This guard is essential: it reproduces a validated supplied reference, not a general stock-refresh engine. For changed stock, rebuild tables from B using the extracted reference layout as a template; do not bypass the guard or silently reuse old prices. Follow the user's requested scope and format rather than automatically delivering every reference page.

Preserve correct B values when C has a documented inconsistency. The Garden Regency reference's Tower 3 E header says 391 sq ft, while its map/B say 360. The renderer uses 360 and adds a visible explanation; stock notes must contain the source evidence. Keep the provided listed PSF discrepancies (Tower 2 2/F F 19,098 vs calculated 19,099; Tower 3 2/F F 18,500 vs calculated 18,000) distinct rather than inventing corrected source rates.

Verify every page's visual tree, displayed text, images, callouts and original positions independently against C, allowing only documented header corrections. Reconcile 240 listed units plus two references across the four map pages, and 916 populated price/rate fields against B. Inspect the full map and native table crops; render the compiled PDF and compare it with its SVG pages. Keep the source dates (19–20 July 2026 in this snapshot) and qualify current availability as unconfirmed. Never replace them with the generation date.

Deliver only the single full-map SVG by default. Supply PNGs, separate map SVGs and a complete PDF with payment-plan annexes only when requested. Do not overwrite the user's source/reference PDF.
