# Garden Regency / 芊御 reference

Use `assets/garden-regency-full-estate.json` and its paired 2048 × 1448 original JPEG as a verified layout asset. Read the user's B afresh each time. Neither this reference nor the saved plan is current stock.

## Full estate mapping

Preserve the whole map: Tower 3 upper-left, Tower 2 lower-left, and Tower 1 lower-right. The JSON records visually checked anchors for:

| Tower | Mapped flats |
|---|---|
| 1 | A, B, C, D, E, F, G, H, J, K, L, M, N, P, Q, R, S |
| 2 | A, B, C, D, E, F, G, H, J, K, L, M |
| 3 | A, B, C, D, E, F, G, H, J, K, L, M |

Protected polygons enclose all three tower drawings and the inset, compass, legend, title, and tower labels. Permit tables over gardens, pools, and paths; keep floor drawings clear. Use the JSON for coordinates and geometry rather than transcribing them from this reference. Tower-colored headers/markers distinguish stacks, e.g. 1C vs 2C vs 3C. Preserve original room-type colors.

The plan depicts standard floors 3, 5–12, and 15–17/F. It permits 2/F as stack-location mapping with a visible caveat that terrace layouts differ. Include per-row saleable and terrace areas. Do not claim the standard map is their exact 2/F floor plan. Use a separate original template for that purpose.

## Multi-plan workbook example

`Garden_Regency_Available_Units(1).xlsx` contained source dates 19–20 July 2026, sheets `Listed Units` and `Floor References`, and a statement that current availability was unconfirmed. This is a historical extraction example, not an inventory feed.

The verified snapshot had 240 unique listed units: Tower 1 = 90, Tower 2 = 54, Tower 3 = 96. It had 216 A1/B1 pairs, 240 quoted prices, 23 reference-price units, one tender-price unit, and 24 terrace units on 2/F. Two additional mid-floor references for Tower 2 K/L had no exact floor/quantity and were excluded from the 240 count.

Display floor, saleable area, terrace area, quoted HKD, A1 HKD, B1 HKD, quoted PSF, calculated PSF, and price type. Keep unpublished plan prices dashed. Retain provided PSF discrepancies: Tower 2 2/F F has listed 19,098 vs calculated 19,099; Tower 3 2/F F has listed 18,500 vs calculated 18,000. Preserve workbook notes rather than silently correcting figures. Tender dates/status come from B, never a hardcoded renderer date.

The all-stock example fits 39 tables on one full-map SVG at scale 4, numeric size 16, and row height 24. Small vector text is intentional; users zoom manually. Tables may combine standard and terrace rows when area columns expose differences. More columns/rows may require a larger whole-map scale or additional full-map pages.

This generic nine-column example does not match the user's supplied presentation reference. Use the reference-matching workflow and preserve its A1/B1/光猪價 headings. The user's accepted final deliverable is one full-map SVG with all three towers and 216 standard-floor rows. The reference's terrace pages, two mid-floor examples and payment-plan annexes are evidence, not default deliverables; include them only when requested. Correct the documented Tower 3 E header to 360 sq ft with a visible note. If all 240 stock rows are explicitly requested on one map, show special-floor stock in distinct annotated location groups. Never treat verified prices alone as proof that the requested presentation was reproduced.

## Historical Batch 1 example

Developer Price List No. 1 (`芊御-1號價單(1).pdf`), printed 9 July 2026, contained 120 Tower 2 units on file pages 2–16: ten flats A, B, C, D, E, F, G, H, J, M × twelve standard floors 17, 16, 15, 12, 11, 10, 9, 8, 7, 6, 5, 3. Do not add K/L, Towers 1/3, or omitted floors to that batch. Values were original listed prices before discounts, with live availability unverified.

For a requested Tower 2 Flat C selection of that source, retain its twelve real rows. Endpoint prices were HK$4,679,800 at 3/F and HK$4,868,400 at 17/F, with the latter's listed rate HK$16,846/sq ft. Verify all rows from the actual source instead of reconstructing prices from endpoints. Keep the full three-tower map even for a single-flat selection; add no duplicate Tower 2 enlargement.
