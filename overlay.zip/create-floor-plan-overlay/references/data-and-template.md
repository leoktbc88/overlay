# Data and template contracts

## Stock schema 2: all named prices

Use explicit ordered columns so no price plan is silently discarded. Add any supplied A1/B1/C1 or other plan; labels must retain their exact meaning. This example is illustrative, not live stock:

```json
{
  "schema_version": 2,
  "estate": "芊御", "phase": "",
  "source": {
    "file": "uploaded-stock.xlsx", "date": "2026-07-20",
    "dates": ["2026-07-19", "2026-07-20"],
    "kind": "price_list", "label": "單位及付款方案",
    "price_basis": "原表列載；各付款方案分列",
    "availability_note": "按來源列載；最新售況未核實。"
  },
  "columns": [
    {"key":"floor", "label":"樓層", "format":"floor", "width":96},
    {"key":"saleable_sqft", "label":"實用呎", "format":"number", "width":58},
    {"key":"terrace_sqft", "label":"露台呎", "format":"number", "width":58},
    {"key":"quoted_hkd", "label":"報價 HK$", "format":"money", "width":113},
    {"key":"A1_hkd", "label":"A1 HK$", "format":"money", "width":113},
    {"key":"B1_hkd", "label":"B1 HK$", "format":"money", "width":113},
    {"key":"price_type", "label":"方式", "format":"text", "width":62}
  ],
  "units": [{
    "tower":"2", "floor":"17", "flat":"C", "bedrooms":"1",
    "saleable_sqft":289, "terrace_sqft":null,
    "quoted_hkd":4868400, "A1_hkd":null, "B1_hkd":null,
    "price_type":"價單", "layout_id":"standard",
    "source_date":"2026-07-20", "source_ref":"Listed Units!9",
    "notes":"", "display_note":null
  }],
  "references": []
}
```

Require `estate`, `source`, and nonempty `units`. Every row must explicitly contain every column key, using null for unpublished values. Accept `floor`, `number`, `money`, and `text` formats. Widths are minimums; the renderer expands them using exact font metrics. Money is shown in HKD with comma-separated figures. Use positive numeric values or null; never substitute zero or another plan's price. Preserve supplied listed/calculated rate columns separately. Add short `status` columns when statuses affect interpretation.

Use `source.kind` as `price_list`, `available_only`, or `full_inventory`. A price list is not proof of live availability. An available-only snapshot describes its listed rows; absent rows have unknown status. A full inventory requires explicit per-row status. Preserve unknown source statuses without inferring sold/available.

Require per-row `source_ref` such as `Sheet1!23` or `PDF p5 row8`. Retain original notes in `notes`; SVG tooltips preserve them. Set optional `display_note` to a short verified, visible qualifier such as an expired tender deadline. Never invent a deadline from generation time. Keep source dates distinct from generation dates.

Keep identifiers as strings and preserve meaningful labels. Reject duplicate tower/floor/flat identities even if prices match. Keep unspecified-floor examples in `references` with a unique `reference_id` and an explicit floor label such as `中層未指定`. References use the same columns, are visibly distinct, and never count as units. Do not invent their quantity or floor.

## Legacy stock schema 1

Retain compatibility for a deliberately selected single price basis. Use `schema_version: 1`, the same estate/source/units envelope, and row fields `tower`, `floor`, `flat`, `saleable_sqft`, `bedrooms`, `layout_id`, `price_hkd`, `price_per_sqft_hkd`, `rate_basis`, `status`, and `source_ref`. Default columns are floor, price, and rate. If any legacy row has a status, explicitly provide `status: null` on the other rows. Use `rate_basis: "calculated"` only for an authorized derived rate and label it clearly. Never flatten multiple named prices into this schema without an explicit user selection.

## Plan JSON and protected geometry

```json
{
  "schema_version":1, "estate":"芊御", "phase":"",
  "image":"original.jpg", "image_sha256":"EXACT_SHA256",
  "image_dimensions":[2048,1448],
  "applicable_floors":["3","5","6","7","8","9","10","11","12","15","16","17"],
  "layout_mode":"background", "map_scale":4,
  "numeric_font_size":16, "row_height":24,
  "max_rows_per_card":24, "grid_step":48,
  "map_role":"stack_location",
  "floor_note":"標準層圖則；2/F只顯示座/室位置，其間隔以專用圖則為準。",
  "anchors":[{
    "tower":"2", "flat":"C", "x":521, "y":852,
    "bedrooms":"1", "color":"#176181", "side":"left",
    "map_floors":["3","5","6","7","8","9","10","11","12","15","16","17"],
    "stack_location_floors":["2"]
  }],
  "protected_regions":[{
    "kind":"tower", "tower":"2",
    "points":[[425,742],[688,742],[692,1322],[420,1322]]
  }]
}
```

The sample polygon illustrates Tower 2 only; a real template must protect EVERY tower in A, including towers with no selected stock. Add `kind: "landmark"` polygons for important labels, inset, compass, legend, and title. Match the bundled image checksum/dimensions exactly. Resolve `image` relative to its JSON or use an absolute path. Coordinates use the original image's top-left origin. Never reuse coordinates after rotation or source-image changes without review.

Use one full unaltered image. Visually check every requested tower/flat anchor on its actual floor drawing, avoiding duplicated inset labels. Protect complete drawings, including protrusions and labels needed to read them. Tables may cover all other map backgrounds. Polygon masks drive placement; an independent geometry verifier checks that tables intersect neither protected regions nor each other.

Use exact applicable floors for actual floor geometry. For different layouts, use separate templates. Location-only overlays need `map_role: "stack_location"`, a nonempty visible `floor_note`, and explicit `stack_location_floors` on each affected anchor. They identify the stack, not the exact terrace/penthouse floor shape. Show per-row areas when layouts change; without an area column the renderer splits area/layout variants.

Background mode measures cells, places cards near anchors on safe areas, and routes leaders around other towers/cards. Increase the whole-map scale or paginate when necessary; do not crop/enlarge one tower or hide source rows. Each page repeats one full estate map. Legacy templates without `layout_mode: "background"` retain side-table layout; `side`, `route: "bottom"`, and `corridor_x` control legacy leaders.

## Extraction, rendering, and verification

Extract native PDF text/coordinates or spreadsheet cells first. Independently re-read numeric column bands, raw workbook XML, or compare source rows visually. Handle formula caches explicitly. For scans, inspect OCR at high resolution. Exclude repeated headers, summaries, and terms from unit counts. Preserve sheet/page/row references. Use B as authoritative data, never presentation C or historical bundled examples.

Write a separate verified-data JSON; the renderer is a compositor, not a universal OCR/parser. Do not call uncertain prices or anchors verified. Use `--tower`/`--flat` only for an explicit selection. Missing anchors, conflicting duplicates, changed image bytes, omitted column values, and unsupported floors must fail visibly.

Run `scripts/build_overlay.py` then `scripts/verify_overlay.py` with identical inputs/selection and all output pages. Schema 2 verifies all displayed named cells, references, source data, exact full-map bytes, marker coordinates, and table/polygon collisions. Also inspect full PNG and native-resolution table crops for glyphs, clipping, leader routes, and footnotes. Source artwork retains its original resolution; new tables/text are vectors with embedded font subsets. `--png` requires Inkscape and uses the same subsets.

Install `scripts/requirements.txt` versions only when dependencies are missing. Keep intermediate checks temporary; save only requested final SVG/PNG artifacts.
