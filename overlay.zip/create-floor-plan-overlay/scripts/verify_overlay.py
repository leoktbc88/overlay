#!/usr/bin/env python3
"""Independently compare SVG displayed data, full map and selected source rows."""
import argparse
import base64
from collections import Counter
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

NS = {'svg': 'http://www.w3.org/2000/svg'}
XLINK = '{http://www.w3.org/1999/xlink}href'


def key(row):
    return tuple(str(row[field]).strip() for field in ('tower', 'floor', 'flat'))


def money(value):
    if value is None:
        return '—'
    decimal = Decimal(str(value).replace(',', ''))
    raw = format(decimal, ',f')
    if '.' in raw:
        raw = raw.rstrip('0').rstrip('.')
    return '$' + raw


def floor(value):
    value = str(value).strip()
    return value if value.upper().endswith('/F') or re.search('[樓層]', value) else value + '/F'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stock', required=True)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--tower', action='append')
    parser.add_argument('--flat', action='append')
    parser.add_argument('svg_files', nargs='+')
    args = parser.parse_args()
    first_root = ET.parse(args.svg_files[0]).getroot()
    first_metadata = json.loads(first_root.find("svg:metadata[@id='source-data']", NS).text)
    if first_metadata.get('schema_version') == 2:
        from verify_background_overlay import run
        run(args)
        return
    stock = json.loads(Path(args.stock).read_text())
    plan_path = Path(args.plan).resolve()
    plan = json.loads(plan_path.read_text())
    original = (plan_path.parent / plan['image']).read_bytes()
    assert hashlib.sha256(original).hexdigest() == plan['image_sha256'], 'Source hash mismatch'
    selected = [r for r in stock['units'] if (not args.tower or str(r['tower']) in args.tower) and (not args.flat or str(r['flat']) in args.flat)]
    expected = {key(row): row for row in selected}
    assert len(expected) == len(selected) and selected, 'Duplicate or empty selected source'
    displayed, pages = Counter(), set()
    for path in args.svg_files:
        root = ET.parse(path).getroot()
        assert root.attrib['viewBox'].startswith('0 0 '), 'Missing scene coordinate system'
        metadata = json.loads(root.find("svg:metadata[@id='source-data']", NS).text)
        assert metadata['source'] == stock['source'], 'Source/date/basis differs'
        assert metadata['estate'] == stock['estate'], 'Estate differs'
        assert metadata['original_map_sha256'] == plan['image_sha256'], 'Embedded metadata hash differs'
        page_key = metadata['page']
        assert page_key not in pages, 'Repeated page'
        pages.add(page_key)
        asset = root.find(".//svg:image[@id='original-plan-asset']", NS)
        assert base64.b64decode(asset.attrib[XLINK].split(',', 1)[1]) == original, 'Background bytes changed'
        uses = root.findall('.//svg:use', NS)
        assert len(uses) == 1 and uses[0].attrib[XLINK] == '#original-plan-asset', 'Expected exactly one full map instance'
        assert root.find('.//svg:clipPath', NS) is None, 'Full-map export must not crop a tower'
        assert '@font-face' in root.find('.//svg:style', NS).text, 'Fonts not embedded'
        raw_rows = [g for g in root.findall('.//svg:g', NS) if g.attrib.get('class') == 'unit-row']
        assert len(raw_rows) == metadata['unit_count'] == len(metadata['units']), 'Page count differs'
        metadata_keys = Counter(key(r) for r in metadata['units'])
        actual_keys = Counter()
        for group in raw_rows:
            unit_key = tuple(group.attrib['data-' + field] for field in ('tower', 'floor', 'flat'))
            assert unit_key in expected, f'Unexpected unit {unit_key}'
            source = expected[unit_key]
            values = {node.attrib['data-field']: node.text for node in group.findall('svg:text', NS)}
            assert values['floor'] == floor(source['floor']), f'Floor label differs: {unit_key}'
            assert values['price'] == money(source.get('price_hkd')), f'Price differs: {unit_key}'
            assert values['rate'] == money(source.get('price_per_sqft_hkd')), f'Rate differs: {unit_key}'
            assert group.attrib['data-source-ref'] == source['source_ref'], 'Source reference differs'
            if 'status' in values:
                status = source.get('status') or ('可售' if stock['source']['kind'] == 'available_only' else '未提供')
                assert values['status'] == status, f'Status differs: {unit_key}'
            actual_keys[unit_key] += 1
            displayed[unit_key] += 1
        assert actual_keys == metadata_keys, 'Displayed and embedded records differ'
        anchors = {(str(a['tower']), str(a['flat'])): a for a in plan['anchors']}
        markers = [g for g in root.findall('.//svg:g', NS) if g.attrib.get('class') == 'flat-marker']
        cards = [g for g in root.findall('.//svg:g', NS) if g.attrib.get('class') == 'price-card']
        leaders = [g for g in root.findall('.//svg:g', NS) if g.attrib.get('class') == 'flat-leader']
        assert len(markers) == len(cards) == len(leaders), 'Card/marker/leader count differs'
        mx, my, scale = metadata['map_transform']
        assert scale == 1, 'Full source map must have no enlarged duplicate'
        for marker in markers:
            anchor_key = (marker.attrib['data-tower'], marker.attrib['data-flat'])
            anchor = anchors[anchor_key]
            assert float(marker.attrib['data-source-x']) == float(anchor['x'])
            assert float(marker.attrib['data-source-y']) == float(anchor['y'])
            circle = marker.find('svg:circle', NS)
            assert float(circle.attrib['cx']) == mx + float(anchor['x'])
            assert float(circle.attrib['cy']) == my + float(anchor['y'])
    assert displayed == Counter({unit_key: 1 for unit_key in expected}), 'Missing, duplicated or extra units across pages'
    assert len(pages) == len(args.svg_files), 'Page set mismatch'
    print(json.dumps({'verified_units': len(expected), 'pages': len(pages), 'original_image_preserved': True, 'full_map_only': True, 'displayed_values_match_source': True}))


if __name__ == '__main__':
    main()
