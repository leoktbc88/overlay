#!/usr/bin/env python3
"""Check reference SVG geometry, source coverage, headers, and embedded fonts."""
import argparse
import base64
from collections import Counter
import hashlib
from io import BytesIO
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

import fitz
from fontTools.ttLib import TTFont

SVG = 'http://www.w3.org/2000/svg'
NS = {'s': SVG}


def fingerprint(node, font_names=None):
    if node.tag in {f'{{{SVG}}}{tag}' for tag in ('metadata','style','title','desc')} or node.attrib.get('id') in {'reference-paper','reference-correction-note'}:
        return None
    attrs = dict(node.attrib)
    if font_names and 'font-family' in attrs:
        attrs['font-family'] = font_names[attrs['font-family']]
    children = [value for child in node if (value := fingerprint(child,font_names)) is not None]
    return [node.tag,sorted(attrs.items()),node.text or '',children]


def row_key(row):
    return tuple(str(row[field]) for field in ('tower','floor','flat'))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference',required=True)
    parser.add_argument('--stock',required=True)
    parser.add_argument('--pages',nargs='+',type=int)
    parser.add_argument('svg_files',nargs='+')
    args=parser.parse_args()
    document=fitz.open(args.reference)
    stock=json.loads(Path(args.stock).read_text())
    stock_hash=hashlib.sha256(Path(args.stock).read_bytes()).hexdigest()
    reference_hash=hashlib.sha256(Path(args.reference).read_bytes()).hexdigest()
    expected={(kind,row_key(row)):row for kind,rows in [('unit',stock['units']),('reference',stock.get('references',[]))] for row in rows}
    assert len(expected)==len(stock['units'])+len(stock.get('references',[])),'Duplicate stock records'
    required_pages=set(args.pages or range(1,len(document)+1))
    observed_pages=set();seen=Counter();populated=0;glyphs=0
    for filename in args.svg_files:
        root=ET.parse(filename).getroot()
        data=json.loads(root.find("s:metadata[@id='source-data']",NS).text)
        page_number=data['page'];assert page_number in required_pages and page_number not in observed_pages
        observed_pages.add(page_number)
        assert data['reference_sha256']==reference_hash and data['stock_sha256']==stock_hash,'Source bytes changed'
        assert data['source']==stock['source']
        page=document[page_number-1]
        original=ET.fromstring(page.get_svg_image(text_as_path=False))
        for correction in data.get('documented_area_header_corrections',[]):
            identity=(correction['tower'],correction['flat'])
            values={str(row['saleable_sqft']) for row in stock['units'] if (row['tower'],row['flat'])==identity and row.get('layout_id')=='standard'}
            assert values=={correction['new'][:-1]},'Corrected header differs from stock areas'
            matches=[]
            for tspan in original.findall('.//s:tspan',NS):
                if tspan.text==correction['old'] and abs(float(tspan.attrib['x'].split()[0])-correction['origin'][0])<.03 and abs(float(tspan.attrib['y'])+page.rect.height-correction['origin'][1])<.03:
                    matches.append(tspan)
            assert len(matches)==1,'Header correction did not target one exact reference span'
            matches[0].text=correction['new']
            note=root.find("s:text[@id='reference-correction-note']",NS)
            assert note is not None and correction['new'][:-1] in note.text and correction['old'][:-1] in note.text,'Visible area note missing'
        reverse={item['embedded_family']:item['original_family'] for item in data['font_mappings']}
        assert fingerprint(root,reverse)==fingerprint(original),'Map, table, price text, callout, or page geometry differs from reference'
        fonts={family:TTFont(BytesIO(base64.b64decode(encoded))).getBestCmap() for family,encoded in re.findall(r'font-family:"([^"]+)";[^}]*base64,([^)]*)\)',root.find('.//s:style',NS).text or '')}
        for node in root.findall('.//s:text',NS):
            cmap=fonts[node.attrib['font-family']]
            assert all(ord(char) in cmap for char in ''.join(node.itertext())),'A displayed glyph lacks its embedded font'
            glyphs+=len(''.join(node.itertext()))
        for row in data['records']:
            identity=(row['record_kind'],row_key(row))
            assert identity in expected,'Unexpected unit/reference'
            source=expected[identity]
            assert row['verified_stock_row']==source,'Verified worksheet values or source-row evidence lost'
            for field in ('A1_hkd','B1_hkd','quoted_hkd','quoted_psf'):
                assert row.get(field)==source.get(field),f'Price mismatch on {identity}, {field}'
                populated+=row.get(field) is not None
            seen[identity]+=1
    assert observed_pages==required_pages,'Missing reference pages'
    selected_pages=required_pages
    if selected_pages==set(range(1,len(document)+1)) or selected_pages=={1,4,5,6}:
        assert seen==Counter({identity:1 for identity in expected}),'Missing/duplicated source units or references'
    print(json.dumps({'verified_svg_pages':sorted(observed_pages),'verified_units':sum(count for (kind,_),count in seen.items() if kind=='unit'),
        'verified_references':sum(count for (kind,_),count in seen.items() if kind=='reference'),'verified_populated_price_fields':populated,
        'portable_glyphs_verified':glyphs,'reference_map_tables_and_callouts_preserved':True,'only_documented_area_header_corrections':True}))


if __name__=='__main__':
    main()
