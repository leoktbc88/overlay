#!/usr/bin/env python3
"""Compose verified stock rows on one full estate map; preserve vector text."""
import argparse
import base64
from collections import defaultdict
from datetime import date
from decimal import Decimal, InvalidOperation
import hashlib
from io import BytesIO
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET

import fitz
from fontTools import subset
from fontTools.ttLib import TTFont
from PIL import Image
import reportlab

SVG = 'http://www.w3.org/2000/svg'
XLINK = 'http://www.w3.org/1999/xlink'
ET.register_namespace('', SVG)
ET.register_namespace('xlink', XLINK)


def element(parent, tag, text=None, **attrs):
    node = ET.SubElement(parent, f'{{{SVG}}}{tag}', {
        key.replace('_', '-'): str(value) for key, value in attrs.items()
        if value is not None
    })
    if text is not None:
        node.text = str(text)
    return node


def identifier(value, label):
    if value is None or isinstance(value, bool) or not str(value).strip():
        raise ValueError(f'Missing {label}')
    return str(value).strip()


def number(value, label, optional=False):
    if optional and value is None:
        return None
    if isinstance(value, bool):
        raise ValueError(f'Invalid {label}: boolean')
    try:
        result = Decimal(str(value).replace(',', ''))
    except InvalidOperation as exc:
        raise ValueError(f'Invalid {label}: {value!r}') from exc
    if not result.is_finite() or result <= 0:
        raise ValueError(f'Invalid {label}: {value!r}')
    return result


def formatted(value, currency=False):
    if value is None:
        return '—'
    val = Decimal(str(value).replace(',', ''))
    result = format(val, ',f').rstrip('0').rstrip('.') if '.' in format(val, 'f') else format(val, ',f')
    return ('$' if currency else '') + result


def floor_label(value):
    value = str(value)
    return value if value.upper().endswith('/F') or re.search(r'[樓層]', value) else value + '/F'


def floor_sort(value):
    clean = str(value).upper().removesuffix('/F')
    if clean in {'G', 'GROUND'}:
        return (0, 0, '')
    if re.fullmatch(r'\d+', clean):
        return (1, int(clean), '')
    if re.fullmatch(r'B\d+', clean):
        return (0, -int(clean[1:]), '')
    return (2, 0, clean)


def load_inputs(stock_path, plan_path, towers=None, flats=None):
    stock = json.loads(Path(stock_path).read_text())
    plan_path = Path(plan_path).resolve()
    plan = json.loads(plan_path.read_text())
    if stock.get('schema_version') != 1 or plan.get('schema_version') != 1:
        raise ValueError('Require schema_version 1 on stock and plan')
    for field in ('estate', 'phase'):
        if str(stock.get(field, '')) != str(plan.get(field, '')):
            raise ValueError(f'Stock and plan {field} differ; review mapping')
    identifier(stock.get('estate'), 'estate')
    source = stock['source']
    for field in ('file', 'price_basis'):
        identifier(source.get(field), f'source.{field}')
    if source.get('kind') not in {'price_list', 'available_only', 'full_inventory'}:
        raise ValueError('Source kind must distinguish price list and inventory')
    if source.get('date'):
        date.fromisoformat(source['date'])
    image_path = (plan_path.parent / plan['image']).resolve()
    image_bytes = image_path.read_bytes()
    if hashlib.sha256(image_bytes).hexdigest() != plan['image_sha256']:
        raise ValueError('Changed image checksum; visually review/remap anchors')
    with Image.open(BytesIO(image_bytes)) as image:
        dims, image_format = list(image.size), image.format
    if dims != plan['image_dimensions'] or image_format not in {'JPEG', 'PNG'}:
        raise ValueError('Plan image dimensions/format differ from approved template')
    anchors = {}
    for anchor in plan['anchors']:
        key = (identifier(anchor.get('tower'), 'anchor tower'), identifier(anchor.get('flat'), 'anchor flat'))
        if key in anchors:
            raise ValueError(f'Duplicate anchor {key}')
        if anchor.get('side') not in {'left', 'right'}:
            raise ValueError(f'Invalid card side for {key}')
        x, y = float(anchor['x']), float(anchor['y'])
        if not (0 <= x <= dims[0] and 0 <= y <= dims[1]):
            raise ValueError(f'Anchor outside original map: {key}')
        if not re.fullmatch(r'#[0-9a-fA-F]{6}', anchor.get('color', '#244b37')):
            raise ValueError(f'Invalid marker color for {key}')
        if not anchor.get('applicable_floors', plan.get('applicable_floors')):
            raise ValueError(f'Missing applicable floors for {key}')
        anchors[key] = anchor
    rows, seen = [], set()
    if not isinstance(stock.get('units'), list) or not stock['units']:
        raise ValueError('Stock units must be a nonempty list')
    requested_towers = set(map(str, towers or []))
    requested_flats = set(map(str, flats or []))
    for raw in stock['units']:
        row = dict(raw)
        for field in ('tower', 'floor', 'flat'):
            row[field] = identifier(row.get(field), field)
        key = (row['tower'], row['floor'], row['flat'])
        if key in seen:
            raise ValueError(f'Duplicate unit identity: {key}; resolve source records')
        seen.add(key)
        if requested_towers and row['tower'] not in requested_towers:
            continue
        if requested_flats and row['flat'] not in requested_flats:
            continue
        anchor_key = (row['tower'], row['flat'])
        if anchor_key not in anchors:
            raise ValueError(f'Unmapped tower/flat {anchor_key}; add verified anchor or filter explicitly')
        anchor = anchors[anchor_key]
        allowed = {str(v) for v in anchor.get('applicable_floors', plan.get('applicable_floors', []))}
        if row['floor'] not in allowed:
            raise ValueError(f'Floor {key} outside approved layout; use the correct template')
        row['saleable_sqft'] = str(number(row.get('saleable_sqft'), 'saleable_sqft'))
        for field in ('price_hkd', 'price_per_sqft_hkd'):
            val = number(row.get(field), field, optional=True)
            row[field] = str(val) if val is not None else None
        row['rate_basis'] = row.get('rate_basis', 'listed')
        if row['rate_basis'] not in {'listed', 'calculated'}:
            raise ValueError(f'Invalid rate basis on {key}')
        row['source_ref'] = identifier(row.get('source_ref'), 'source_ref')
        row['bedrooms'] = str(row.get('bedrooms', anchor.get('bedrooms', '')))
        row['layout_id'] = str(row.get('layout_id', 'standard'))
        row['status'] = str(row['status']).strip() if row.get('status') else None
        if source['kind'] == 'full_inventory' and not row['status']:
            raise ValueError(f'Full inventory requires explicit status: {key}')
        if source['kind'] == 'available_only' and row['status'] is None:
            row['status'] = '可售'
        rows.append(row)
    if not rows:
        raise ValueError('No units match the requested selection')
    for requested in requested_towers:
        if not any(r['tower'] == requested for r in rows):
            raise ValueError(f'Requested tower {requested} has no selected units')
    for requested in requested_flats:
        if not any(r['flat'] == requested for r in rows):
            raise ValueError(f'Requested flat {requested} has no selected units')
    return stock, plan, anchors, rows, image_bytes, image_format.lower()


def paginate(rows, anchors):
    grouped = defaultdict(list)
    for row in rows:
        key = (row['tower'], row['flat'], row['saleable_sqft'], row['bedrooms'], row['layout_id'], row['rate_basis'])
        grouped[key].append(row)
    queues = {'left': [], 'right': []}
    for key, group in grouped.items():
        group.sort(key=lambda r: floor_sort(r['floor']), reverse=True)
        side = anchors[key[:2]]['side']
        for offset in range(0, len(group), 12):
            queues[side].append(group[offset:offset + 12])
    for queue in queues.values():
        queue.sort(key=lambda g: (float(anchors[(g[0]['tower'], g[0]['flat'])]['y']), g[0]['tower'], g[0]['flat']))
    pages = []
    while any(queues.values()):
        page = {'left': [], 'right': []}
        for side in page:
            used = set()
            remaining = []
            for group in queues[side]:
                key = (group[0]['tower'], group[0]['flat'])
                if len(page[side]) < 5 and key not in used:
                    page[side].append(group)
                    used.add(key)
                else:
                    remaining.append(group)
            queues[side] = remaining
        pages.append(page)
    return pages


class Fonts:
    def __init__(self, folder):
        font_root = Path(reportlab.__file__).parent / 'fonts'
        self.sources = [
            (fitz.Font('china-t').buffer, 'OverlayCJK', 'Regular'),
            ((font_root / 'Vera.ttf').read_bytes(), 'OverlayLatin', 'Regular'),
            ((font_root / 'VeraBd.ttf').read_bytes(), 'OverlayLatin', 'Bold')]
        self.folder = Path(folder)
        self.cjk = fitz.Font('china-t')
        self.regular = fitz.Font(fontfile=str(font_root / 'Vera.ttf'))
        self.bold = fitz.Font(fontfile=str(font_root / 'VeraBd.ttf'))
        self.latin_cmap = TTFont(BytesIO(self.sources[1][0])).getBestCmap()

    def width(self, text, size, bold=False):
        latin = self.bold if bold else self.regular
        return sum((latin if ord(ch) in self.latin_cmap else self.cjk).text_length(ch, fontsize=size) for ch in text)

    def wrap(self, text, size, width, maximum=2):
        lines, current = [], ''
        for char in text:
            if self.width(current + char, size) > width:
                lines.append(current)
                current = char
            else:
                current += char
        if current:
            lines.append(current)
        if len(lines) > maximum:
            raise ValueError(f'Text needs more than {maximum} lines: {text}; adjust layout')
        return lines

    def css(self, text):
        required = {ord(ch) for ch in text if not ch.isspace()}
        available = set().union(*(TTFont(BytesIO(src)).getBestCmap() for src, _, _ in self.sources))
        missing = required - available
        if missing:
            raise ValueError('Unsupported font glyphs: ' + ''.join(map(chr, sorted(missing))))
        css = []
        for source, family, style in self.sources:
            font = TTFont(BytesIO(source))
            options = subset.Options()
            options.name_IDs = [0, 1, 2, 3, 4, 5, 6, 13, 14, 16, 17]
            sub = subset.Subsetter(options=options)
            sub.populate(text=text)
            sub.subset(font)
            name = family if style == 'Regular' else f'{family}-{style}'
            for record in font['name'].names:
                replacements = {1: family, 2: style, 3: name, 4: name, 6: name, 16: family, 17: style}
                if record.nameID in replacements:
                    record.string = replacements[record.nameID].encode(record.getEncoding())
            font.flavor = None
            font.save(self.folder / f'{name}.ttf')
            font.flavor = 'woff'
            stream = BytesIO()
            font.save(stream)
            uri = base64.b64encode(stream.getvalue()).decode()
            weight = 700 if style == 'Bold' else 400
            css.append(f"@font-face{{font-family:{family};src:url('data:font/woff;base64,{uri}') format('woff');font-weight:{weight};}}")
        css.append('text{font-family:OverlayLatin,OverlayCJK,sans-serif;} .strong{font-weight:700;} .numeric{font-variant-numeric:tabular-nums;}')
        return '\n'.join(css)


def build_page(stock, plan, anchors, page, page_index, page_count, total, image_bytes, image_format, fonts):
    rows = [row for side in page.values() for group in side for row in group]
    has_status = any(row['status'] for row in rows)
    cw, ch, step, start = (660 if has_status else 480), 354, 370, 120
    iw, ih = plan['image_dimensions']
    width = iw + 2 * cw + 220
    mx, my = cw + 100, start + max(0, (5 * step - 16 - ih) / 2)
    table_bottom = start + 4 * step + ch
    footer_y = max(table_bottom, my + ih + 100) + 50
    height = footer_y + 90
    root = ET.Element(f'{{{SVG}}}svg', {'width': str(width), 'height': str(height), 'viewBox': f'0 0 {width} {height}', 'preserveAspectRatio': 'xMidYMid meet', 'fill': '#263c30', 'role': 'img', 'aria-labelledby': 'title description'})
    title = f"{stock['estate']} · {stock['source'].get('label', '單位價表')}"
    element(root, 'title', title, id='title')
    element(root, 'desc', 'One full estate floor map with verified vector stock tables, markers and leaders. Zoom to read small text; no separate tower enlargement.', id='description')
    metadata = {'schema_version': 1, 'estate': stock['estate'], 'phase': stock.get('phase', ''), 'source': stock['source'], 'page': page_index, 'pages': page_count, 'total_selected': total, 'unit_count': len(rows), 'units': rows, 'original_map_sha256': plan['image_sha256'], 'map_dimensions': plan['image_dimensions'], 'map_transform': [mx, my, 1], 'anchors': [anchors[(g[0]['tower'], g[0]['flat'])] for side in page.values() for g in side]}
    element(root, 'metadata', json.dumps(metadata, ensure_ascii=False), id='source-data')
    defs = element(root, 'defs')
    style = element(defs, 'style')
    image_uri = f'data:image/{image_format};base64,' + base64.b64encode(image_bytes).decode()
    image = element(defs, 'image', id='original-plan-asset', width=iw, height=ih)
    image.set(f'{{{XLINK}}}href', image_uri)
    arrow = element(defs, 'marker', id='leader-arrow', viewBox='0 0 12 12', refX=11, refY=6, markerWidth=3.5, markerHeight=3.5, orient='auto')
    element(arrow, 'path', d='M0 0 L12 6 L0 12 Z', fill='#244b37')
    element(root, 'rect', width=width, height=height, fill='#f7f8f2')

    def text(parent, content, x, y, size=18, max_width=None, bold=False, **attrs):
        if max_width is not None and fonts.width(content, size, bold) > max_width:
            raise ValueError(f'Text exceeds column width: {content!r}; expand or split, do not clip')
        return element(parent, 'text', content, x=x, y=y, font_size=size, **{'class': 'numeric strong' if bold else 'numeric'}, **attrs)

    text(root, title, 40, 49, 32, max_width=width / 2)
    text(root, f'{total} 個列載單位 · 本頁 {len(rows)} 個 · {page_index}/{page_count}', width - 40, 45, 20, text_anchor='end')
    source_date = stock['source'].get('date') or '未提供日期'
    text(root, f"資料日期 {source_date} | {stock['source']['price_basis']}", 40, 83, 17, max_width=width - 80)
    plan_group = element(root, 'g', id='full-estate-map', transform=f'translate({mx} {my})')
    use = element(plan_group, 'use')
    use.set(f'{{{XLINK}}}href', '#original-plan-asset')
    element(root, 'rect', x=mx, y=my, width=iw, height=ih, fill='none', stroke='#a1b29e', stroke_width=1)
    for side, groups in page.items():
        for index, group in enumerate(groups):
            row = group[0]
            key = (row['tower'], row['flat'])
            anchor = anchors[key]
            x = 40 if side == 'left' else mx + iw + 60
            y = start + index * step
            tx, ty = mx + float(anchor['x']), my + float(anchor['y'])
            sy = y + 177
            if side == 'left':
                path = f'M {x + cw} {sy} C {mx - 35} {sy} {mx - 35} {ty} {mx} {ty} L {tx - 17} {ty}'
            elif anchor.get('route') == 'bottom':
                outer_x = width - 20 - index * 8
                bottom_y = my + ih + 76 - index * 12
                corridor_x = mx + float(anchor.get('corridor_x', anchor['x'] + 80))
                path = f'M {x + cw} {sy} L {outer_x} {sy} L {outer_x} {bottom_y} L {corridor_x} {bottom_y} L {corridor_x} {ty} L {tx + 17} {ty}'
            else:
                path = f'M {x} {sy} C {mx + iw + 35} {sy} {mx + iw + 35} {ty} {mx + iw} {ty} L {tx + 17} {ty}'
            leader = element(root, 'g', **{'class': 'flat-leader'}, data_tower=key[0], data_flat=key[1])
            element(leader, 'path', d=path, fill='none', stroke='#fffdf4', stroke_width=5, stroke_linejoin='round')
            element(leader, 'path', d=path, fill='none', stroke='#315b42', stroke_width=1.8, stroke_linejoin='round', marker_end='url(#leader-arrow)')
            marker = element(root, 'g', **{'class': 'flat-marker'}, data_tower=key[0], data_flat=key[1], data_source_x=anchor['x'], data_source_y=anchor['y'])
            element(marker, 'circle', cx=tx, cy=ty, r=15, fill=anchor.get('color', '#244b37'), stroke='#fffdf4', stroke_width=2)
            text(marker, key[1], tx, ty + 5, 14, max_width=24, bold=True, fill='#ffffff', text_anchor='middle')
            card = element(root, 'g', transform=f'translate({x} {y})', **{'class': 'price-card'}, data_tower=key[0], data_flat=key[1], data_unit_count=len(group))
            element(card, 'rect', width=cw, height=ch, rx=9, fill='#ffffff', stroke='#7e9b80', stroke_width=1)
            element(card, 'path', d=f'M9 0 H{cw-9} Q{cw} 0 {cw} 9 V64 H0 V9 Q0 0 9 0 Z', fill=anchor.get('color', '#244b37'))
            text(card, f'第{key[0]}座 {key[1]}室', 14, 28, 23, max_width=cw - 130, fill='#ffffff')
            text(card, f'{len(group)} 個單位', cw - 14, 26, 13, fill='#ffffff', text_anchor='end')
            bedroom = f"{row['bedrooms']}房 | " if row['bedrooms'] else ''
            subtitle = bedroom + formatted(row['saleable_sqft']) + ' 平方呎'
            if row['layout_id'] != 'standard':
                subtitle += ' | ' + row['layout_id']
            text(card, subtitle, 14, 53, 15, max_width=cw - 28, fill='#ffffff')
            element(card, 'rect', y=64, width=cw, height=29, fill='#e8eee3')
            price_x, rate_x = 278, 462
            text(card, '樓層', 14, 84, 15)
            text(card, '售價（HK$）', 100, 84, 15)
            rate_heading = '每呎價（計算）' if row['rate_basis'] == 'calculated' else '每呎價（HK$）'
            text(card, rate_heading, 308, 84, 15, max_width=160)
            if has_status:
                text(card, '來源狀態', 500, 84, 15)
            for offset, unit in enumerate(group):
                ry = 93 + offset * 19
                rg = element(card, 'g', **{'class': 'unit-row'}, data_tower=unit['tower'], data_floor=unit['floor'], data_flat=unit['flat'], data_source_ref=unit['source_ref'])
                if offset % 2:
                    element(rg, 'rect', y=ry, width=cw, height=19, fill='#f0f4ec')
                text(rg, floor_label(unit['floor']), 14, ry + 15, 17, max_width=80, data_field='floor')
                text(rg, formatted(unit['price_hkd'], True), price_x, ry + 15, 18, max_width=180, bold=True, text_anchor='end', data_field='price')
                text(rg, formatted(unit['price_per_sqft_hkd'], True), rate_x, ry + 15, 18, max_width=166, text_anchor='end', data_field='rate')
                if has_status:
                    text(rg, unit['status'] or '未提供', 500, ry + 15, 16, max_width=cw - 514, data_field='status')
            element(card, 'line', x1=12, y1=324, x2=cw - 12, y2=324, stroke='#c6d1c0')
            refs = '、'.join(dict.fromkeys(unit['source_ref'] for unit in group))
            for offset, line in enumerate(fonts.wrap('來源：' + refs, 12, cw - 28, maximum=2)):
                text(card, line, 14, 338 + offset * 12, 12)
    meaning = {'price_list': '價單列載資料；最新售況未核實。', 'available_only': '可售快照；未列單位狀態未確認。', 'full_inventory': '按來源的各單位狀態顯示。'}[stock['source']['kind']]
    footer = f"來源：{stock['source']['file']} | {source_date} | {meaning}"
    text(root, footer, 40, footer_y, 16, max_width=width - 80)
    text(root, '全盤樓層圖保留；表格、文字、標記及連線為SVG向量。請放大閱讀。', 40, footer_y + 32, 16, max_width=width - 80)
    all_text = ''.join(node.text or '' for node in root.iter(f'{{{SVG}}}text'))
    style.text = fonts.css(all_text)
    return ET.ElementTree(root), width, height


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stock', required=True)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--output', required=True, help='SVG filename; pagination adds -p01, -p02')
    parser.add_argument('--tower', action='append', help='Explicit tower selection; repeat if needed')
    parser.add_argument('--flat', action='append', help='Flat selection; repeat if needed')
    parser.add_argument('--png', action='store_true', help='Render identical scene with local Inkscape')
    args = parser.parse_args()
    preview_plan = json.loads(Path(args.plan).read_text())
    if preview_plan.get('layout_mode') == 'background':
        from build_background_overlay import run
        run(args)
        return
    stock, plan, anchors, rows, image_bytes, image_format = load_inputs(args.stock, args.plan, args.tower, args.flat)
    pages = paginate(rows, anchors)
    output = Path(args.output).resolve()
    if output.suffix.lower() != '.svg':
        raise ValueError('Output must end in .svg')
    output.parent.mkdir(parents=True, exist_ok=True)
    files = []
    with tempfile.TemporaryDirectory(prefix='floor-overlay-fonts-') as temp:
        fonts = Fonts(temp)
        config = Path(temp) / 'fonts.conf'
        config.write_text(f'<?xml version="1.0"?><fontconfig><dir>{temp}</dir><cachedir>{temp}/cache</cachedir></fontconfig>')
        for index, page in enumerate(pages, 1):
            target = output if len(pages) == 1 else output.with_name(f'{output.stem}-p{index:02d}.svg')
            tree, width, height = build_page(stock, plan, anchors, page, index, len(pages), len(rows), image_bytes, image_format, fonts)
            tree.write(target, encoding='utf-8', xml_declaration=True)
            files.append(str(target))
            if args.png:
                inkscape = shutil.which('inkscape')
                if not inkscape:
                    raise ValueError('SVG created; PNG requires Inkscape or another verified renderer')
                png = target.with_suffix('.png')
                environment = dict(os.environ, FONTCONFIG_FILE=str(config))
                result = subprocess.run([inkscape, str(target), '--export-type=png', '--export-filename=' + str(png), '--export-width=' + str(width)], env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
                if result.returncode or not png.is_file():
                    raise ValueError('PNG rendering failed; inspect renderer locally without dumping embedded font data')
                files.append(str(png))
                with Image.open(png) as check:
                    if check.size != (int(width), int(height)):
                        raise ValueError('PNG dimensions differ from SVG scene')
    print(json.dumps({'files': files, 'pages': len(pages), 'selected_units': len(rows), 'input_units': len(stock['units']), 'excluded_by_explicit_filter': len(stock['units']) - len(rows), 'towers': sorted({row['tower'] for row in rows}), 'map_instances_per_page': 1, 'numeric_font_size': 18}, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, FileNotFoundError) as error:
        raise SystemExit(f'ERROR: {error}')
