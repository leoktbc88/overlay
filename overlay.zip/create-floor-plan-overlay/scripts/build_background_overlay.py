#!/usr/bin/env python3
"""Place named-price tables over safe map backgrounds without covering towers."""
from collections import defaultdict
from datetime import date
import hashlib
import heapq
from io import BytesIO
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image, ImageDraw
from build_overlay import Fonts, SVG, XLINK, element, identifier, number, formatted, floor_label, floor_sort


def value_text(row, column):
    value = row.get(column['key'])
    if value is None:
        return '—'
    kind = column['format']
    if kind == 'floor':
        return floor_label(value)
    if kind in {'money', 'number'}:
        return formatted(value, kind == 'money')
    return str(value)


def read_inputs(args):
    stock = json.loads(Path(args.stock).read_text())
    plan_path = Path(args.plan).resolve()
    plan = json.loads(plan_path.read_text())
    if stock.get('schema_version') not in {1, 2}:
        raise ValueError('Stock schema_version must be 1 or 2')
    if plan.get('schema_version') != 1 or not plan.get('protected_regions'):
        raise ValueError('Background layout requires approved protected tower regions')
    for field in ('estate', 'phase'):
        if str(stock.get(field, '')) != str(plan.get(field, '')):
            raise ValueError(f'Stock and template {field} differ')
    source = stock['source']
    for field in ('file', 'price_basis'):
        identifier(source.get(field), 'source.' + field)
    if source.get('kind') not in {'price_list', 'available_only', 'full_inventory'}:
        raise ValueError('Source kind must distinguish price list and inventory')
    for day in [source.get('date'), *source.get('dates', [])]:
        if day:
            date.fromisoformat(day)
    image_bytes = (plan_path.parent / plan['image']).read_bytes()
    if hashlib.sha256(image_bytes).hexdigest() != plan['image_sha256']:
        raise ValueError('Changed original image; review/remap anchors and protected regions')
    with Image.open(BytesIO(image_bytes)) as image:
        dimensions, image_format = list(image.size), image.format.lower()
    if dimensions != plan['image_dimensions'] or image_format not in {'jpeg', 'png'}:
        raise ValueError('Source image dimensions/format differ from approved template')
    anchors = {}
    for anchor in plan['anchors']:
        key = (str(anchor['tower']), str(anchor['flat']))
        if key in anchors:
            raise ValueError(f'Duplicate anchor {key}')
        if not 0 <= anchor['x'] <= dimensions[0] or not 0 <= anchor['y'] <= dimensions[1]:
            raise ValueError(f'Anchor outside original map: {key}')
        anchors[key] = anchor
    protected_towers = set()
    for region in plan['protected_regions']:
        points = region.get('points', [])
        if len(points) < 3 or any(len(point) != 2 or not all(math.isfinite(float(v)) for v in point) or not 0 <= point[0] <= dimensions[0] or not 0 <= point[1] <= dimensions[1] for point in points):
            raise ValueError('Protected polygons need at least three finite source-image points')
        if region.get('kind') == 'tower':
            protected_towers.add(str(region.get('tower')))
    if not {key[0] for key in anchors}.issubset(protected_towers):
        raise ValueError('Every mapped tower needs a protected floor-drawing polygon')
    if stock['schema_version'] == 2 and not stock.get('columns'):
        raise ValueError('Stock schema 2 requires explicit named columns')
    columns = stock.get('columns') or [
        {'key': 'floor', 'label': '樓層', 'format': 'floor', 'width': 80},
        {'key': 'price_hkd', 'label': '售價 HK$', 'format': 'money', 'width': 150},
        {'key': 'price_per_sqft_hkd', 'label': '每呎價 HK$', 'format': 'money', 'width': 115},
    ]
    if stock.get('schema_version') == 1 and any(r.get('status') for r in stock['units']):
        columns.append({'key': 'status', 'label': '來源狀態', 'format': 'text', 'width': 120})
    keys = [c['key'] for c in columns]
    if len(set(keys)) != len(keys) or 'floor' not in keys:
        raise ValueError('Column keys must be unique and include floor')
    for column in columns:
        if column.get('format') not in {'floor', 'number', 'money', 'text'}:
            raise ValueError('Unknown column format')
        identifier(column.get('label'), 'column label')
    units, references, seen = [], [], set()
    for kind, collection in [('unit', stock['units']), ('reference', stock.get('references', []))]:
        for raw in collection:
            row = dict(raw)
            for field in ('tower', 'floor', 'flat'):
                row[field] = identifier(row.get(field), field)
            identity = (row['tower'], row['floor'], row['flat']) if kind == 'unit' else identifier(row.get('reference_id'), 'reference_id')
            if (kind, identity) in seen:
                raise ValueError(f'Duplicate {kind} identity: {identity}')
            seen.add((kind, identity))
            if args.tower and row['tower'] not in args.tower:
                continue
            if args.flat and row['flat'] not in args.flat:
                continue
            anchor = anchors.get((row['tower'], row['flat']))
            if not anchor:
                raise ValueError(f'Unmapped tower/flat: {row["tower"]}/{row["flat"]}')
            if kind == 'unit':
                allowed = set(map(str, anchor.get('map_floors', anchor.get('applicable_floors', plan.get('applicable_floors', [])))))
                if plan.get('map_role') == 'stack_location' and plan.get('floor_note'):
                    allowed.update(map(str, anchor.get('stack_location_floors', [])))
                if row['floor'] not in allowed:
                    raise ValueError(f'Floor {identity} outside mapped layout/location scope')
            row['source_ref'] = identifier(row.get('source_ref'), 'source_ref')
            if row.get('source_date'):
                date.fromisoformat(row['source_date'])
            for column in columns:
                field = column['key']
                if field not in row:
                    raise ValueError(f'Missing explicit column value {field} on {identity}; use null for unpublished values')
                if column['format'] in {'number', 'money'}:
                    number(row[field], field, optional=True)
            if source['kind'] == 'full_inventory' and not row.get('status'):
                raise ValueError(f'Full inventory requires source status: {identity}')
            if source['kind'] == 'available_only' and not row.get('status'):
                row['status'] = '可售'
            row['_record_kind'] = kind
            (units if kind == 'unit' else references).append(row)
    if not units:
        raise ValueError('No unit records match selection')
    for field, values in [('tower', args.tower), ('flat', args.flat)]:
        for requested in values or []:
            if not any(r[field] == requested for r in units):
                raise ValueError(f'Requested {field} {requested} has no units')
    return stock, plan, anchors, columns, units, references, image_bytes, image_format


def make_cards(units, references, anchors, columns, fonts, plan):
    body = float(plan.get('numeric_font_size', 16))
    row_height = max(float(plan.get('row_height', 24)), body + 5)
    for column in columns:
        widest = max(fonts.width(value_text(row, column), body, column['format'] == 'money') for row in units + references)
        column['width'] = max(float(column.get('width', 60)), widest + 18, fonts.width(column['label'], 13) + 18)
    width = math.ceil(sum(c['width'] for c in columns) + 24)
    grouped = defaultdict(list)
    for row in units + references:
        grouped[(row['tower'], row['flat'])].append(row)
    maximum = int(plan.get('max_rows_per_card', 24))
    if maximum < 1:
        raise ValueError('max_rows_per_card must be positive')
    cards = []
    show_area_per_row = 'saleable_sqft' in {c['key'] for c in columns}
    for key, rows in grouped.items():
        rows.sort(key=lambda r: (r['_record_kind'] == 'unit', floor_sort(r['floor'])), reverse=True)
        if not show_area_per_row:
            variants = defaultdict(list)
            for row in rows:
                variants[(row.get('saleable_sqft'), row.get('layout_id', 'standard'))].append(row)
            groups = list(variants.values())
        else:
            groups = [rows]
        for group in groups:
            for offset in range(0, len(group), maximum):
                part = group[offset:offset + maximum]
                note = []
                if any(r.get('layout_id') == 'terrace-2F' for r in part):
                    note.append('2/F露台另則')
                if any(r['_record_kind'] == 'reference' for r in part):
                    note.append('中層未指定，不計單位數')
                note.extend(dict.fromkeys(r['display_note'] for r in part if r.get('display_note')))
                cards.append({'tower': key[0], 'flat': key[1], 'rows': part, 'anchor': anchors[key], 'width': width, 'height': math.ceil(84 + len(part) * row_height + 42 + (20 if note else 0)), 'note': '；'.join(note), 'body_size': body, 'row_height': row_height})
    cards.sort(key=lambda c: (-c['height'], c['tower'], float(c['anchor']['y']), c['flat']))
    return cards


CELL = 8


def protected_points(region, mx, my, scale):
    return [(mx + float(x) * scale, my + float(y) * scale) for x, y in region['points']]


def mask_for(width, height, regions, cards=(), exclude_tower=None, card_pad=20):
    image = Image.new('L', (math.ceil(width / CELL), math.ceil(height / CELL)), 0)
    draw = ImageDraw.Draw(image)
    for region in regions:
        if exclude_tower is not None and region.get('tower') == exclude_tower:
            continue
        draw.polygon([(x / CELL, y / CELL) for x, y in region['scene_points']], fill=1)
    for card in cards:
        gap = card_pad
        draw.rectangle(((card['x'] - gap) / CELL, (card['y'] - gap) / CELL, (card['x'] + card['width'] + gap) / CELL, (card['y'] + card['height'] + gap) / CELL), fill=1)
    return np.asarray(image, dtype=np.uint8).copy()


def place_cards(cards, plan, width, height, mx, my, scale, regions):
    iw, ih = plan['image_dimensions']
    step = max(16, int(plan.get('grid_step', 48)))
    pages, remaining = [], list(cards)
    while remaining:
        mask = mask_for(width, height, regions)
        placed, leftovers = [], []
        for card in remaining:
            xs = np.arange(mx + 24, mx + iw * scale - card['width'] - 24, step)
            ys = np.arange(my + 24, my + ih * scale - card['height'] - 24, step)
            gx, gy = np.meshgrid(xs, ys)
            gx, gy = gx.ravel(), gy.ravel()
            pad = 20
            x1 = np.floor((gx - pad) / CELL).astype(int)
            y1 = np.floor((gy - pad) / CELL).astype(int)
            x2 = np.ceil((gx + card['width'] + pad) / CELL).astype(int) + 1
            y2 = np.ceil((gy + card['height'] + pad) / CELL).astype(int) + 1
            integral = np.pad(mask.astype(np.int32).cumsum(0).cumsum(1), ((1, 0), (1, 0)))
            scores = integral[y2, x2] - integral[y1, x2] - integral[y2, x1] + integral[y1, x1]
            valid = scores == 0
            if not valid.any():
                leftovers.append(card)
                continue
            tx, ty = mx + card['anchor']['x'] * scale, my + card['anchor']['y'] * scale
            costs = (gx + card['width'] / 2 - tx) ** 2 + (gy + card['height'] / 2 - ty) ** 2
            costs[~valid] = np.inf
            chosen = int(np.argmin(costs))
            current = dict(card, x=int(gx[chosen]), y=int(gy[chosen]))
            placed.append(current)
            xa, ya, xb, yb = x1[chosen], y1[chosen], x2[chosen], y2[chosen]
            mask[ya:yb, xa:xb] = 1
        if not placed:
            raise ValueError('No card fits safe map background; enlarge the full-map scene or define additional safe margins')
        pages.append(placed)
        remaining = leftovers
    return pages


def route(card, cards, regions, width, height, mx, my, scale):
    tx, ty = mx + card['anchor']['x'] * scale, my + card['anchor']['y'] * scale
    x, y, w, h = card['x'], card['y'], card['width'], card['height']
    choices = [(x - 28, min(max(ty, y + 15), y + h - 15), x, min(max(ty, y + 15), y + h - 15)), (x + w + 28, min(max(ty, y + 15), y + h - 15), x + w, min(max(ty, y + 15), y + h - 15)), (min(max(tx, x + 15), x + w - 15), y - 28, min(max(tx, x + 15), x + w - 15), y), (min(max(tx, x + 15), x + w - 15), y + h + 28, min(max(tx, x + 15), x + w - 15), y + h)]
    mask = mask_for(width, height, regions, cards, exclude_tower=card['tower'], card_pad=4)
    choices.sort(key=lambda point: (point[0] - tx) ** 2 + (point[1] - ty) ** 2)
    start_point = next((p for p in choices if 0 <= p[0] < width and 0 <= p[1] < height and not mask[int(p[1] / CELL), int(p[0] / CELL)]), None)
    if start_point is None:
        raise ValueError(f'Card leader {card["tower"]}/{card["flat"]} at {x},{y},{w},{h} has no unobstructed exit; increase table spacing')
    start = (int(start_point[0] / CELL), int(start_point[1] / CELL))
    goal = (int(tx / CELL), int(ty / CELL))
    frontier = [(0.0, start)]
    previous, costs = {}, {start: 0.0}
    neighbors = [(1, 0, 1), (-1, 0, 1), (0, 1, 1), (0, -1, 1), (1, 1, 1.4143), (1, -1, 1.4143), (-1, 1, 1.4143), (-1, -1, 1.4143)]
    while frontier:
        _, current = heapq.heappop(frontier)
        if current == goal:
            break
        for dx, dy, cost in neighbors:
            nx, ny = current[0] + dx, current[1] + dy
            if not 0 <= nx < mask.shape[1] or not 0 <= ny < mask.shape[0] or mask[ny, nx]:
                continue
            if dx and dy and (mask[current[1], nx] or mask[ny, current[0]]):
                continue
            candidate = costs[current] + cost
            node = (nx, ny)
            if candidate < costs.get(node, float('inf')):
                costs[node] = candidate
                previous[node] = current
                heuristic = math.hypot(goal[0] - nx, goal[1] - ny)
                heapq.heappush(frontier, (candidate + heuristic, node))
    if goal not in costs:
        raise ValueError(f'Cannot route leader for {card["tower"]}/{card["flat"]}; adjust placement')
    nodes, cursor = [goal], goal
    while cursor != start:
        cursor = previous[cursor]
        nodes.append(cursor)
    nodes.reverse()
    simplified = [nodes[0]]
    for index in range(1, len(nodes) - 1):
        a, b, c = nodes[index - 1], nodes[index], nodes[index + 1]
        if (b[0] - a[0], b[1] - a[1]) != (c[0] - b[0], c[1] - b[1]):
            simplified.append(b)
    simplified.append(nodes[-1])
    points = [(start_point[2], start_point[3]), (start_point[0], start_point[1]), *[(px * CELL + CELL / 2, py * CELL + CELL / 2) for px, py in simplified], (tx, ty)]
    return points


def draw_page(stock, plan, columns, cards, page, pages, total, refs_total, image_bytes, image_format, fonts, width, height, mx, my, scale, regions):
    root = ET.Element(f'{{{SVG}}}svg', {'width': str(width), 'height': str(height), 'viewBox': f'0 0 {width} {height}', 'preserveAspectRatio': 'xMidYMid meet', 'fill': '#263c30', 'role': 'img'})
    title = stock['estate'] + ' ' + stock['source'].get('label', '單位及付款方案')
    element(root, 'title', title)
    element(root, 'desc', 'One full estate map. Tables may cover gardens and other backgrounds, and never the protected tower floor drawings. Named prices remain separate vector columns.')
    rows = [row for card in cards for row in card['rows']]
    units = [r for r in rows if r['_record_kind'] == 'unit']
    references = [r for r in rows if r['_record_kind'] == 'reference']
    layout = [{key: card[key] for key in ('tower', 'flat', 'x', 'y', 'width', 'height')} for card in cards]
    metadata = {'schema_version': 2, 'estate': stock['estate'], 'phase': stock.get('phase', ''), 'source': stock['source'], 'columns': columns, 'page': page, 'pages': pages, 'total_selected': total, 'reference_total': refs_total, 'unit_count': len(units), 'units': units, 'references': references, 'original_map_sha256': plan['image_sha256'], 'map_dimensions': plan['image_dimensions'], 'map_transform': [mx, my, scale], 'map_role': plan.get('map_role', 'floor_layout'), 'floor_note': plan.get('floor_note'), 'protected_regions': regions, 'card_layout': layout, 'numeric_font_size': plan.get('numeric_font_size', 16)}
    element(root, 'metadata', json.dumps(metadata, ensure_ascii=False), id='source-data')
    defs = element(root, 'defs')
    style = element(defs, 'style')
    import base64
    asset = element(defs, 'image', id='original-plan-asset', width=plan['image_dimensions'][0], height=plan['image_dimensions'][1])
    asset.set(f'{{{XLINK}}}href', f'data:image/{image_format};base64,' + base64.b64encode(image_bytes).decode())
    element(root, 'rect', width=width, height=height, fill='#f7f8f2')
    map_group = element(root, 'g', id='full-estate-map', transform=f'translate({mx} {my}) scale({scale})')
    image = element(map_group, 'use')
    image.set(f'{{{XLINK}}}href', '#original-plan-asset')

    def text(parent, content, x, y, size=16, maximum=None, bold=False, **attrs):
        if maximum is not None and fonts.width(content, size, bold) > maximum:
            raise ValueError(f'Text does not fit: {content}; expand the column or card')
        return element(parent, 'text', content, x=x, y=y, font_size=size, **{'class': 'numeric strong' if bold else 'numeric'}, **attrs)

    text(root, title, 60, 57, 36)
    text(root, f'{total} 個列載單位 + {refs_total} 項中層參考 · {page}/{pages}', width - 60, 54, 24, text_anchor='end')
    dates = ' / '.join(stock['source'].get('dates') or [stock['source'].get('date') or '未提供日期'])
    text(root, '資料日期 ' + dates + ' · ' + stock['source']['price_basis'], 60, 97, 21, maximum=width - 120)
    tower_colors = {'1': '#835133', '2': '#244b37', '3': '#274b65'}
    for card in cards:
        points = route(card, cards, regions, width, height, mx, my, scale)
        color = tower_colors.get(card['tower'], '#244b37')
        path = 'M ' + ' L '.join(f'{x:.1f} {y:.1f}' for x, y in points)
        leader = element(root, 'g', **{'class': 'flat-leader'}, data_tower=card['tower'], data_flat=card['flat'])
        element(leader, 'path', d=path, fill='none', stroke='#fffdf4', stroke_width=6, stroke_linejoin='round')
        element(leader, 'path', d=path, fill='none', stroke=color, stroke_width=2.2, stroke_linejoin='round')
    for card in cards:
        x, y, w, h = card['x'], card['y'], card['width'], card['height']
        group = element(root, 'g', transform=f'translate({x} {y})', **{'class': 'price-card'}, data_tower=card['tower'], data_flat=card['flat'], data_x=x, data_y=y, data_width=w, data_height=h)
        element(group, 'rect', width=w, height=h, rx=9, fill='#ffffff', stroke='#6d8770', stroke_width=1.2)
        color = tower_colors.get(card['tower'], '#244b37')
        element(group, 'path', d=f'M9 0 H{w-9} Q{w} 0 {w} 9 V58 H0 V9 Q0 0 9 0 Z', fill=color)
        text(group, f'第{card["tower"]}座 {card["flat"]}室', 12, 26, 23, fill='#ffffff')
        unit_count = sum(r['_record_kind'] == 'unit' for r in card['rows'])
        ref_count = len(card['rows']) - unit_count
        count = f'{unit_count} 列載單位' + (f' + {ref_count} 中層參考' if ref_count else '')
        text(group, count, w - 12, 25, 14, fill='#ffffff', text_anchor='end')
        rooms = '、'.join(sorted({r.get('bedrooms', '') for r in card['rows']} - {''}))
        subtitle = (rooms + '房（開放式廚房）' if rooms else '')
        if 'saleable_sqft' not in {c['key'] for c in columns}:
            subtitle += ' · ' + formatted(card['rows'][0]['saleable_sqft']) + ' 平方呎'
        text(group, subtitle, 12, 48, 14, maximum=w - 24, fill='#ffffff')
        element(group, 'rect', y=58, width=w, height=26, fill='#e8eee3')
        positions, current_x = [], 12.0
        for column in columns:
            positions.append(current_x)
            text(group, column['label'], current_x + column['width'] / 2, 76, 13, maximum=column['width'] - 12, text_anchor='middle', data_column=column['key'])
            current_x += column['width']
        for index, row in enumerate(card['rows']):
            ry = 84 + index * card['row_height']
            kind = row['_record_kind']
            data = dict(data_tower=row['tower'], data_floor=row['floor'], data_flat=row['flat'], data_source_ref=row['source_ref'])
            if kind == 'reference':
                data['data_reference_id'] = row['reference_id']
            rg = element(group, 'g', **{'class': 'unit-row' if kind == 'unit' else 'reference-row'}, **data)
            element(rg, 'title', row['source_ref'] + (' · ' + row['notes'] if row.get('notes') else ''))
            if index % 2 or kind == 'reference':
                element(rg, 'rect', y=ry, width=w, height=card['row_height'], fill='#e7eff5' if kind == 'reference' else '#f0f4ec')
            for column, cx in zip(columns, positions):
                numeric = column['format'] in {'number', 'money'}
                value = value_text(row, column)
                text(rg, value, cx + column['width'] - 8 if numeric else cx + 4, ry + card['body_size'] + 2, card['body_size'], maximum=column['width'] - 12, bold=column['format'] == 'money' and 'psf' not in column['key'], text_anchor='end' if numeric else 'start', data_field=column['key'])
        footer_y = 84 + len(card['rows']) * card['row_height'] + 18
        source_dates = sorted({r.get('source_date') or stock['source'].get('date') or '未提供日期' for r in card['rows']})
        pages_source = sorted({m.group(1) for r in card['rows'] if (m := re.search(r'PDF p(\d+)', r['source_ref']))})
        footer = '日期 ' + '/'.join(source_dates) + (' · PDF ' + ','.join(pages_source) + '頁' if pages_source else '')
        text(group, footer, 12, footer_y, 12, maximum=w - 24)
        if card['note']:
            text(group, card['note'], 12, footer_y + 20, 12, maximum=w - 24, fill='#725227')
    for card in cards:
        tx, ty = mx + card['anchor']['x'] * scale, my + card['anchor']['y'] * scale
        marker = element(root, 'g', **{'class': 'flat-marker'}, data_tower=card['tower'], data_flat=card['flat'], data_source_x=card['anchor']['x'], data_source_y=card['anchor']['y'])
        element(marker, 'circle', cx=tx, cy=ty, r=24, fill=tower_colors.get(card['tower'], '#244b37'), stroke='#fffdf4', stroke_width=3)
        text(marker, card['tower'] + card['flat'], tx, ty + 6, 17, bold=True, fill='#ffffff', text_anchor='middle')
    footer_y = my + plan['image_dimensions'][1] * scale + 39
    text(root, '來源：' + stock['source']['file'] + ' · ' + stock['source'].get('availability_note', '按來源列載；未列單位狀態未確認。'), 60, footer_y, 18, maximum=width - 120)
    text(root, plan.get('floor_note', '全盤背景保留；表格與文字為SVG向量，請放大閱讀。'), 60, footer_y + 30, 17, maximum=width - 120)
    style.text = fonts.css(''.join(node.text or '' for node in root.iter(f'{{{SVG}}}text')))
    return ET.ElementTree(root)


def run(args):
    stock, plan, anchors, columns, units, references, image_bytes, image_format = read_inputs(args)
    scale = float(plan.get('map_scale', 3))
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError('map_scale must be positive and finite')
    mx, my = 60, 130
    width = math.ceil(plan['image_dimensions'][0] * scale + mx * 2)
    height = math.ceil(plan['image_dimensions'][1] * scale + my + 105)
    regions = [dict(region, scene_points=protected_points(region, mx, my, scale)) for region in plan['protected_regions']]
    output = Path(args.output).resolve()
    if output.suffix.lower() != '.svg':
        raise ValueError('Output must end in .svg')
    output.parent.mkdir(parents=True, exist_ok=True)
    files = []
    with tempfile.TemporaryDirectory(prefix='floor-map-fonts-') as folder:
        fonts = Fonts(folder)
        cards = make_cards(units, references, anchors, columns, fonts, plan)
        pages = place_cards(cards, plan, width, height, mx, my, scale, regions)
        config = Path(folder) / 'fonts.conf'
        config.write_text(f'<?xml version="1.0"?><fontconfig><dir>{folder}</dir><cachedir>{folder}/cache</cachedir></fontconfig>')
        for index, page in enumerate(pages, 1):
            target = output if len(pages) == 1 else output.with_name(f'{output.stem}-p{index:02d}.svg')
            tree = draw_page(stock, plan, columns, page, index, len(pages), len(units), len(references), image_bytes, image_format, fonts, width, height, mx, my, scale, regions)
            tree.write(target, encoding='utf-8', xml_declaration=True)
            files.append(str(target))
            if args.png:
                inkscape = shutil.which('inkscape')
                if not inkscape:
                    raise ValueError('SVG is ready; PNG requires Inkscape or another verified renderer')
                png = target.with_suffix('.png')
                result = subprocess.run([inkscape, str(target), '--export-type=png', '--export-filename=' + str(png)], env=dict(os.environ, FONTCONFIG_FILE=str(config)), stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
                if result.returncode or not png.is_file():
                    raise ValueError('PNG render failed; inspect locally without dumping embedded font data')
                with Image.open(png) as image:
                    if image.size != (width, height):
                        raise ValueError('PNG dimensions differ from scene')
                files.append(str(png))
    print(json.dumps({'files': files, 'pages': len(pages), 'selected_units': len(units), 'reference_rows': len(references), 'price_columns': [c['label'] for c in columns], 'tables': len(cards), 'all_towers_preserved': True, 'layout_mode': 'safe_background_overlay', 'numeric_font_size': plan.get('numeric_font_size', 16)}, ensure_ascii=False))
