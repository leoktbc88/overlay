#!/usr/bin/env python3
"""Verify named prices and references independently, plus exact card geometry."""
import base64
from collections import Counter
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

NS = {'s': 'http://www.w3.org/2000/svg'}
XLINK = '{http://www.w3.org/1999/xlink}href'


def display(value, format_name):
    if value is None:
        return '—'
    if format_name == 'floor':
        text = str(value).strip()
        return text if text.upper().endswith('/F') or re.search('[樓層]', text) else text + '/F'
    if format_name in {'money', 'number'}:
        text = format(Decimal(str(value).replace(',', '')), ',f')
        if '.' in text:
            text = text.rstrip('0').rstrip('.')
        return ('$' if format_name == 'money' else '') + text
    return str(value)


def point_in_polygon(point, polygon):
    x, y = point
    inside = False
    for index in range(len(polygon)):
        ax, ay = polygon[index]
        bx, by = polygon[(index + 1) % len(polygon)]
        if (ay > y) != (by > y) and x < (bx - ax) * (y - ay) / (by - ay) + ax:
            inside = not inside
    return inside


def segments_intersect(a, b, c, d):
    def orientation(p, q, r):
        return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])
    def on(p, q, r):
        return min(p[0], r[0]) <= q[0] <= max(p[0], r[0]) and min(p[1], r[1]) <= q[1] <= max(p[1], r[1])
    first, second, third, fourth = orientation(a, b, c), orientation(a, b, d), orientation(c, d, a), orientation(c, d, b)
    if ((first > 0 and second < 0) or (first < 0 and second > 0)) and ((third > 0 and fourth < 0) or (third < 0 and fourth > 0)):
        return True
    return (first == 0 and on(a, c, b)) or (second == 0 and on(a, d, b)) or (third == 0 and on(c, a, d)) or (fourth == 0 and on(c, b, d))


def rect_polygon_intersect(rect, polygon):
    x, y, width, height = rect
    corners = [(x, y), (x + width, y), (x + width, y + height), (x, y + height)]
    if any(x <= px <= x + width and y <= py <= y + height for px, py in polygon):
        return True
    if any(point_in_polygon(point, polygon) for point in corners):
        return True
    return any(segments_intersect(corners[i], corners[(i + 1) % 4], polygon[j], polygon[(j + 1) % len(polygon)]) for i in range(4) for j in range(len(polygon)))


def run(args):
    stock = json.loads(Path(args.stock).read_text())
    plan_path = Path(args.plan).resolve()
    plan = json.loads(plan_path.read_text())
    original = (plan_path.parent / plan['image']).read_bytes()
    assert hashlib.sha256(original).hexdigest() == plan['image_sha256'], 'Source checksum changed'
    selected = lambda row: (not args.tower or str(row['tower']) in args.tower) and (not args.flat or str(row['flat']) in args.flat)
    unit_key = lambda row: tuple(str(row[field]).strip() for field in ('tower', 'floor', 'flat'))
    expected_units = {unit_key(row): row for row in stock['units'] if selected(row)}
    expected_refs = {row['reference_id']: row for row in stock.get('references', []) if selected(row)}
    assert len(expected_units) == sum(selected(row) for row in stock['units']), 'Duplicate source units'
    seen_units, seen_refs, page_numbers = Counter(), Counter(), set()
    cells = 0
    for path in args.svg_files:
        root = ET.parse(path).getroot()
        data = json.loads(root.find("s:metadata[@id='source-data']", NS).text)
        assert data['source'] == stock['source'], 'Source date/price basis differs'
        assert data['original_map_sha256'] == plan['image_sha256']
        assert data['page'] not in page_numbers, 'Duplicate page'
        page_numbers.add(data['page'])
        assert data['total_selected'] == len(expected_units)
        assert data['reference_total'] == len(expected_refs)
        assert len(root.findall('.//s:use', NS)) == 1, 'Expected exactly one full map'
        assert root.find('.//s:clipPath', NS) is None, 'Tower crop is not permitted'
        asset = root.find(".//s:image[@id='original-plan-asset']", NS)
        assert base64.b64decode(asset.attrib[XLINK].split(',', 1)[1]) == original, 'Original artwork changed'
        assert '@font-face' in root.find('.//s:style', NS).text, 'Portable fonts missing'
        columns = data['columns']
        if stock.get('columns'):
            assert [(c['key'], c['label'], c['format']) for c in columns] == [(c['key'], c['label'], c['format']) for c in stock['columns']], 'Named columns lost or mislabeled'
        unit_groups = [g for g in root.findall('.//s:g', NS) if g.attrib.get('class') == 'unit-row']
        reference_groups = [g for g in root.findall('.//s:g', NS) if g.attrib.get('class') == 'reference-row']
        assert len(unit_groups) == data['unit_count'] == len(data['units'])
        assert len(reference_groups) == len(data['references'])
        metadata_units = {unit_key(row): row for row in data['units']}
        metadata_refs = {row['reference_id']: row for row in data['references']}
        for kind, groups, expected in [('unit', unit_groups, expected_units), ('reference', reference_groups, expected_refs)]:
            for group in groups:
                identity = tuple(group.attrib['data-' + field] for field in ('tower', 'floor', 'flat')) if kind == 'unit' else group.attrib['data-reference-id']
                assert identity in expected, f'Unexpected {kind} {identity}'
                source = expected[identity]
                values = {text.attrib['data-field']: text.text for text in group.findall('s:text', NS)}
                assert set(values) == {c['key'] for c in columns}, 'Displayed column missing'
                embedded = (metadata_units if kind == 'unit' else metadata_refs)[identity]
                for column in columns:
                    field = column['key']
                    assert values[field] == display(source.get(field), column['format']), (identity, field, values[field], source.get(field))
                    assert display(embedded.get(field), column['format']) == values[field], 'Embedded value differs'
                    cells += 1
                assert group.attrib['data-source-ref'] == source['source_ref']
                for field in ('source_ref', 'source_date', 'notes', 'display_note', 'layout_id'):
                    assert embedded.get(field) == source.get(field), f'Embedded {field} differs from source'
                (seen_units if kind == 'unit' else seen_refs)[identity] += 1
        mx, my, scale = data['map_transform']
        assert (mx, my, scale) == (60, 130, float(plan.get('map_scale', 3))), 'Unexpected map transform'
        assert root.find(".//s:g[@id='full-estate-map']", NS).attrib['transform'] == f'translate({mx} {my}) scale({scale})', 'Visible map transform differs'
        protected = [[(mx + x * scale, my + y * scale) for x, y in region['points']] for region in plan['protected_regions']]
        card_groups = [g for g in root.findall('.//s:g', NS) if g.attrib.get('class') == 'price-card']
        cards = [tuple(float(g.attrib['data-' + key]) for key in ('x', 'y', 'width', 'height')) for g in card_groups]
        assert len(cards) == len(data['card_layout'])
        for group, card in zip(card_groups, cards):
            assert group.attrib['transform'] == f'translate({int(card[0])} {int(card[1])})', 'Visible table position differs'
            rect = group.find('s:rect', NS)
            assert float(rect.attrib['width']) == card[2] and float(rect.attrib['height']) == card[3], 'Visible table size differs'
            headings = [(text.attrib['data-column'], text.text) for text in group.findall('s:text', NS) if 'data-column' in text.attrib]
            assert headings == [(column['key'], column['label']) for column in columns], 'Visible column labels differ'
        for card in cards:
            assert mx <= card[0] and my <= card[1]
            assert card[0] + card[2] <= mx + plan['image_dimensions'][0] * scale
            assert card[1] + card[3] <= my + plan['image_dimensions'][1] * scale
            assert not any(rect_polygon_intersect(card, polygon) for polygon in protected), 'Table covers a protected tower or map landmark'
        for first in range(len(cards)):
            x, y, w, h = cards[first]
            for other in cards[first + 1:]:
                ox, oy, ow, oh = other
                assert not (x < ox + ow and x + w > ox and y < oy + oh and y + h > oy), 'Tables overlap each other'
        markers = [g for g in root.findall('.//s:g', NS) if g.attrib.get('class') == 'flat-marker']
        leaders = [g for g in root.findall('.//s:g', NS) if g.attrib.get('class') == 'flat-leader']
        assert len(markers) == len(cards) == len(leaders)
        anchors = {(str(a['tower']), str(a['flat'])): a for a in plan['anchors']}
        for marker in markers:
            anchor = anchors[(marker.attrib['data-tower'], marker.attrib['data-flat'])]
            circle = marker.find('s:circle', NS)
            assert float(circle.attrib['cx']) == mx + anchor['x'] * scale
            assert float(circle.attrib['cy']) == my + anchor['y'] * scale
    assert seen_units == Counter({key: 1 for key in expected_units}), 'Missing or duplicated units'
    assert seen_refs == Counter({key: 1 for key in expected_refs}), 'Missing or duplicated references'
    assert page_numbers == set(range(1, len(args.svg_files) + 1)), 'Incomplete page set'
    print(json.dumps({'verified_units': len(expected_units), 'verified_references': len(expected_refs), 'verified_displayed_cells': cells, 'pages': len(args.svg_files), 'all_named_price_columns_preserved': True, 'zero_tables_over_tower_floor_plans': True, 'original_full_map_preserved': True}))
