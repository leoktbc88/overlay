#!/usr/bin/env python3
"""Reproduce a supplied Garden Regency reference with portable, live SVG text.

Require its complete prices to match verified stock before copying layout.
This is reference reproduction, not a way to reuse an old price snapshot.
"""
import argparse
import base64
from collections import defaultdict
from copy import deepcopy
import hashlib
from io import BytesIO
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET

import fitz
import reportlab
from fontTools import subset
from fontTools.ttLib import TTFont, newTable
from fontTools.ttLib.tables._c_m_a_p import CmapSubtable

SVG = 'http://www.w3.org/2000/svg'
NS = {'s': SVG}
ET.register_namespace('', SVG)
ET.register_namespace('xlink', 'http://www.w3.org/1999/xlink')


def key(row):
    return tuple(str(row[field]) for field in ('tower', 'floor', 'flat'))


def extract_records(document):
    records = []
    for page_number, page in enumerate(document, 1):
        text = page.get_text('text')
        starts = list(re.finditer(r'TOWER\s+([123])\s+([A-Z])\s+', text))
        for index, match in enumerate(starts):
            body = text[match.end():starts[index + 1].start() if index + 1 < len(starts) else len(text)]
            header = re.match(r'([123])房[^\n]*\n([^\n]+)', body)
            if not header:
                raise ValueError(f'Unrecognized table header on page {page_number}: {match.groups()}')
            area = re.search(r'(\d+)\s*[\x27\u2019]', header[2])
            terrace = re.search(r'平台\s*(\d+)', header[2])
            common = {'tower': match[1], 'flat': match[2], 'bedrooms': header[1],
                      'pdf_header_area': int(area[1]) if area else None,
                      'terrace_sqft': int(terrace[1]) if terrace else None,
                      'reference_page': page_number}
            if 'A1 Plan' in body and 'B1 Plan' in body:
                rows = re.findall(r'(\d+)/F\s+\$([\d,]+)\s+\$([\d,]+)\s+\$([\d,]+)\s+@([\d,]+)', body)
                for floor, a1, b1, quoted, rate in rows:
                    records.append(dict(common, floor=floor, A1_hkd=int(a1.replace(',', '')),
                        B1_hkd=int(b1.replace(',', '')), quoted_hkd=int(quoted.replace(',', '')),
                        quoted_psf=int(rate.replace(',', '')), price_type='價單', record_kind='unit'))
                if not rows:
                    raise ValueError(f'No standard-floor records in {match.groups()}')
            else:
                row = re.search(r'(2/F|中層)\s+(參考價|招標價)\s+\$([\d,]+)\s+@([\d,]+)', body)
                if not row:
                    raise ValueError(f'Unrecognized reference/tender row in {match.groups()}')
                floor, price_type, quote, rate = row.groups()
                records.append(dict(common, floor='2' if floor == '2/F' else '中層未指定',
                    A1_hkd=None, B1_hkd=None, quoted_hkd=int(quote.replace(',', '')),
                    quoted_psf=int(rate.replace(',', '')), price_type='招標' if price_type == '招標價' else '參考',
                    record_kind='unit' if floor == '2/F' else 'reference'))
    identities = [(r['record_kind'], key(r)) for r in records]
    if len(set(identities)) != len(identities):
        raise ValueError('Reference contains duplicate unit/reference identities')
    if not records:
        raise ValueError('Reference contains no recognized stock tables')
    return records


def compare_stock(records, stock):
    units = stock['units']
    refs = stock.get('references', [])
    expected = {(kind, key(row)): row for kind, rows in [('unit', units), ('reference', refs)] for row in rows}
    if len(expected) != len(units) + len(refs):
        raise ValueError('Duplicate stock identities')
    observed = {(row['record_kind'], key(row)): row for row in records}
    if expected.keys() != observed.keys():
        raise ValueError('Reference and stock identities differ; rebuild the layout from current data instead of reusing this snapshot')
    area_notes, verified, populated = [], 0, 0
    for identity, reference in observed.items():
        source = expected[identity]
        for field in ('A1_hkd', 'B1_hkd', 'quoted_hkd', 'quoted_psf'):
            if reference[field] != source.get(field):
                raise ValueError(f'Reference/current stock price differs: {identity}, {field}; do not reuse old prices')
            verified += 1
            populated += reference[field] is not None
        for field in ('bedrooms', 'terrace_sqft', 'price_type'):
            if str(reference.get(field)) != str(source.get(field)):
                raise ValueError(f'Reference/current stock {field} differs on {identity}')
        if reference['pdf_header_area'] != source.get('saleable_sqft'):
            area_notes.append({'identity': list(identity[1]), 'reference_header_sqft': reference['pdf_header_area'],
                               'stock_sqft': source.get('saleable_sqft'), 'note': source.get('notes'), 'reference_page':reference['reference_page']})
    return {'verified_price_fields': verified, 'verified_populated_price_fields': populated, 'area_discrepancies': area_notes,
            'unit_count': len(units), 'reference_count': len(refs)}


def correct_area_headers(page, root, checks):
    """Apply only documented, uniform header-area discrepancies; retain layout."""
    notes = {(item['identity'][0], item['identity'][2]): item for item in checks['area_discrepancies'] if item['reference_page']==page.number+1}
    for item in notes.values():
        if not item.get('note') or not all(word in item['note'].lower() for word in ('header', 'map')):
            raise ValueError('An area discrepancy needs source evidence before changing a header')
    spans = [span for block in page.get_text('dict')['blocks'] if block['type'] == 0 for line in block['lines'] for span in line['spans']]
    corrections = []
    for index, span in enumerate(spans):
        match = re.fullmatch(r'TOWER ([123])', span['text'].strip())
        if not match or index + 1 == len(spans):
            continue
        identity = (match[1], spans[index + 1]['text'].strip())
        if identity not in notes:
            continue
        note = notes[identity]
        candidates = []
        for following in spans[index + 2:]:
            if following['text'].startswith('TOWER '):
                break
            if re.fullmatch(str(note['reference_header_sqft']) + r"[\x27\u2019]", following['text'].strip()):
                candidates.append(following)
                break
        if len(candidates) != 1:
            raise ValueError('Could not locate the exact area header for a documented correction')
        original = candidates[0]; found = []
        for node in root.findall('.//s:text', NS):
            for tspan in node.findall('s:tspan', NS):
                if tspan.text == original['text'] and abs(float(tspan.attrib['x'].split()[0]) - original['origin'][0]) < .03 and abs(float(tspan.attrib['y']) + page.rect.height - original['origin'][1]) < .03:
                    found.append(tspan)
        if len(found) != 1:
            raise ValueError('Area header SVG mapping is ambiguous')
        replacement = str(note['stock_sqft']) + original['text'][-1]
        if len(replacement) != len(original['text']):
            raise ValueError('Changed area width requires rebuilding the header explicitly')
        found[0].text = replacement
        corrections.append({'tower':identity[0], 'flat':identity[1], 'old':original['text'], 'new':replacement, 'origin':list(original['origin'])})
    if corrections:
        note = '; '.join(f'T{r["tower"]} {r["flat"]}: {r["new"][:-1]} sq ft (reference header {r["old"][:-1]})' for r in corrections) + '. Current availability unconfirmed.'
        node = ET.SubElement(root, f'{{{SVG}}}text', {'id':'reference-correction-note','font-size':'4.4','font-family':'ReferenceNote','x':'7.2','y':'525.8','fill':'#333333'})
        node.text = note
    return corrections


def normalized_font(name):
    name = name.split('+')[-1]
    weight = 'bold' if 'Bold' in name else 'normal'
    if name == 'Arial-BoldMT':
        return ('Arial', 'bold')
    if name == 'Calibri-Bold':
        return ('Calibri', 'bold')
    return (name, weight)


def portable_fonts(document, page, root, folder, page_number):
    text_nodes = root.findall('.//s:text', NS)
    required = defaultdict(set)
    for node in text_nodes:
        required[(node.attrib['font-family'], node.attrib.get('font-weight', 'normal'))].update(''.join(node.itertext()))
    trace = defaultdict(dict)
    for span in page.get_texttrace():
        font_key = normalized_font(span['font'])
        for code, glyph, _, _ in span['chars']:
            if code > 0 and glyph >= 0:
                if code in trace[font_key] and trace[font_key][code] != glyph:
                    raise ValueError('Ambiguous font glyph mapping in reference')
                trace[font_key][code] = glyph
    sources = {}
    for info in page.get_fonts(full=True):
        name, extension, _, content = document.extract_font(info[0])
        if extension != 'ttf' or not content:
            raise ValueError('Reference requires an extractable TrueType font')
        font_key = normalized_font(name)
        if font_key in sources and sources[font_key] != content:
            raise ValueError('Multiple incompatible reference font subsets share one family')
        sources[font_key] = content
    sources[('ReferenceNote', 'normal')] = (Path(reportlab.__file__).parent / 'fonts' / 'Vera.ttf').read_bytes()
    mappings, css = {}, []
    for index, (font_key, chars) in enumerate(required.items()):
        if font_key not in sources:
            raise ValueError(f'No embedded reference font for {font_key}')
        font = TTFont(BytesIO(sources[font_key]))
        try:
            order = font.getGlyphOrder()
        except Exception:
            # Some older decorative fonts have an unsupported post format.
            # PDF texttrace supplies their actual glyph IDs and Unicode pairs.
            post = newTable('post')
            post.formatType, post.italicAngle, post.underlinePosition, post.underlineThickness = 3.0, 0, 0, 0
            post.isFixedPitch = post.minMemType42 = post.maxMemType42 = post.minMemType1 = post.maxMemType1 = 0
            font['post'] = post
            order = ['.notdef'] + [f'glyph{n:05d}' for n in range(1, font['maxp'].numGlyphs)]
            font.setGlyphOrder(order)
        cmap = dict(font.getBestCmap() or {})
        for code, glyph in trace[font_key].items():
            if code not in cmap:
                if glyph >= len(order):
                    raise ValueError('Reference glyph ID is outside its font')
                cmap[code] = order[glyph]
        missing = {ord(ch) for ch in chars} - set(cmap)
        if missing:
            raise ValueError(f'Missing portable glyphs for {font_key}: {missing}')
        table = newTable('cmap'); table.tableVersion = 0
        unicode_map = CmapSubtable.newSubtable(12)
        unicode_map.platformID, unicode_map.platEncID, unicode_map.language = 3, 10, 0
        unicode_map.cmap = cmap; table.tables = [unicode_map]; font['cmap'] = table
        family = f'ReferencePage{page_number}Font{index}'
        style = 'Bold' if font_key[1] == 'bold' else 'Regular'
        for name_id, value in [(1, family), (2, style), (4, family + ' ' + style), (6, family + '-' + style), (16, family), (17, style)]:
            font['name'].setName(value, name_id, 3, 1, 0x409)
            font['name'].setName(value, name_id, 1, 0, 0)
        options = subset.Options(); options.drop_tables += ['FFTM']
        options.name_IDs = [1, 2, 4, 6, 16, 17]
        sub = subset.Subsetter(options=options); sub.populate(text=''.join(chars)); sub.subset(font)
        font.flavor = None; font.save(folder / (family + '.ttf'))
        font.flavor = 'woff'; buffer = BytesIO(); font.save(buffer)
        encoded = base64.b64encode(buffer.getvalue()).decode()
        css.append(f'@font-face{{font-family:"{family}";font-weight:{700 if font_key[1] == "bold" else 400};src:url(data:font/woff;base64,{encoded}) format("woff");}}')
        mappings[font_key] = family
    for node in text_nodes:
        font_key = (node.attrib['font-family'], node.attrib.get('font-weight', 'normal'))
        node.set('font-family', mappings[font_key])
    return '\n'.join(css), [{'original_family': k[0], 'weight': k[1], 'embedded_family': v} for k, v in mappings.items()]


def visual_tree(node, reverse_fonts=None):
    if node.tag in {f'{{{SVG}}}{name}' for name in ('metadata', 'style', 'title', 'desc')} or node.attrib.get('id') == 'reference-paper':
        return None
    attrs = dict(node.attrib)
    if reverse_fonts and 'font-family' in attrs:
        attrs['font-family'] = reverse_fonts[attrs['font-family']]
    return [node.tag, sorted(attrs.items()), node.text or '', [tree for child in node if (tree := visual_tree(child, reverse_fonts)) is not None]]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference', required=True)
    parser.add_argument('--stock', required=True)
    parser.add_argument('--output', required=True, help='First-page SVG; subsequent pages use -pNN')
    parser.add_argument('--pages', nargs='+', type=int, help='One-based page selection; defaults to every reference page')
    parser.add_argument('--png', action='store_true')
    parser.add_argument('--pdf', help='Optional complete PDF compiled from all reference pages')
    parser.add_argument('--preview-width', type=int, default=3600)
    args = parser.parse_args()
    reference, stock_path = Path(args.reference), Path(args.stock)
    stock = json.loads(stock_path.read_text())
    document = fitz.open(reference)
    records = extract_records(document); checks = compare_stock(records, stock)
    stock_lookup = {(kind,key(row)):row for kind,rows in [('unit',stock['units']),('reference',stock.get('references',[]))] for row in rows}
    pages = args.pages or list(range(1, len(document) + 1))
    if len(set(pages)) != len(pages) or any(p < 1 or p > len(document) for p in pages):
        raise ValueError('Invalid reference page selection')
    if args.pdf and pages != list(range(1, len(document) + 1)):
        raise ValueError('A complete PDF requires all reference pages in order')
    output = Path(args.output).resolve(); output.parent.mkdir(parents=True, exist_ok=True)
    if output.suffix != '.svg':
        raise ValueError('SVG output must end in .svg')
    renderer = shutil.which('inkscape')
    if (args.png or args.pdf) and not renderer:
        raise ValueError('PNG/PDF output requires Inkscape')
    files, temporary_pdfs, page_report = [], [], []
    with tempfile.TemporaryDirectory(prefix='reference-overlay-fonts-') as temporary:
        folder = Path(temporary); config = folder / 'fonts.conf'
        config.write_text(f'<?xml version="1.0"?><fontconfig><dir>{folder}</dir><cachedir>{folder}/cache</cachedir></fontconfig>')
        environment = dict(os.environ, FONTCONFIG_FILE=str(config))
        for page_number in pages:
            page = document[page_number - 1]
            root = ET.fromstring(page.get_svg_image(text_as_path=False))
            corrections = correct_area_headers(page, root, checks)
            original = deepcopy(root)
            css, mappings = portable_fonts(document, page, root, folder, page_number)
            defs = root.find('s:defs', NS)
            if defs is None:
                defs = ET.SubElement(root, f'{{{SVG}}}defs')
            ET.SubElement(defs, f'{{{SVG}}}style').text = css
            root.insert(1, ET.Element(f'{{{SVG}}}rect', {'id':'reference-paper','width':str(page.rect.width),'height':str(page.rect.height),'fill':'#ffffff'}))
            page_records = [dict(r,verified_stock_row=stock_lookup[(r['record_kind'],key(r))]) for r in records if r['reference_page'] == page_number]
            data = {'schema_version':3, 'layout_mode':'supplied_reference', 'reference_sha256':hashlib.sha256(reference.read_bytes()).hexdigest(),
                    'stock_sha256':hashlib.sha256(stock_path.read_bytes()).hexdigest(), 'page':page_number, 'pages':len(document),
                    'reference_file':reference.name, 'source':stock['source'], 'records':page_records, 'stock_comparison':checks,
                    'font_mappings':mappings, 'new_text_is_vector':True, 'raster_annex':not bool(page.get_text().strip())}
            data['documented_area_header_corrections'] = corrections
            ET.SubElement(root, f'{{{SVG}}}metadata', {'id':'source-data'}).text = json.dumps(data,ensure_ascii=False)
            reverse = {m['embedded_family']:m['original_family'] for m in mappings}
            if visual_tree(root, reverse) != visual_tree(original):
                raise ValueError('Reference geometry/text changed while embedding fonts')
            target = output if page_number == 1 else output.with_name(f'{output.stem}-p{page_number:02d}.svg')
            ET.ElementTree(root).write(target,encoding='utf-8',xml_declaration=True); files.append(str(target))
            if args.png:
                png = target.with_suffix('.png')
                result = subprocess.run([renderer,str(target),'--export-area-page','--export-width='+str(args.preview_width),'--export-filename='+str(png)],env=environment,capture_output=True,timeout=90)
                if result.returncode or not png.exists():
                    raise ValueError(f'PNG render failed on page {page_number}')
                files.append(str(png))
            if args.pdf:
                pdf = folder / f'page-{page_number:02d}.pdf'
                pdf_root = deepcopy(root)
                pdf_root.set('width', str(page.rect.width) + 'pt')
                pdf_root.set('height', str(page.rect.height) + 'pt')
                physical_svg = folder / f'page-{page_number:02d}-physical.svg'
                ET.ElementTree(pdf_root).write(physical_svg,encoding='utf-8',xml_declaration=True)
                result = subprocess.run([renderer,str(physical_svg),'--export-area-page','--export-filename='+str(pdf)],env=environment,capture_output=True,timeout=90)
                if result.returncode or not pdf.exists():
                    raise ValueError(f'PDF render failed on page {page_number}')
                temporary_pdfs.append(pdf)
            page_report.append({'page':page_number,'units':sum(r['record_kind']=='unit' for r in page_records),'references':sum(r['record_kind']=='reference' for r in page_records),'svg':str(target),'live_text_nodes':len(root.findall('.//s:text',NS))})
        if args.pdf:
            merged = fitz.open()
            for pdf in temporary_pdfs:
                page_pdf = fitz.open(pdf); merged.insert_pdf(page_pdf); page_pdf.close()
            merged.set_metadata({'title':'Garden Regency — reference-matched floor-plan and price overlays','subject':'Reference layout preserved; all supplied price fields reconciled against uploaded stock.'})
            merged.save(args.pdf,garbage=4,deflate=True); merged.close();files.append(str(Path(args.pdf).resolve()))
    print(json.dumps({'files':files,'comparison':checks,'pages':page_report,'reference_layout_preserved':True},ensure_ascii=False))


if __name__ == '__main__':
    main()
